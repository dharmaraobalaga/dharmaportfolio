import { useEffect } from 'react';

/** Adds `.is-in` to `.reveal` elements as they enter the viewport. No-op when motion is reduced. */
export function useReveal(dep: unknown) {
  useEffect(() => {
    const els = Array.from(document.querySelectorAll<HTMLElement>('.reveal:not(.is-in)'));
    if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      els.forEach((el) => el.classList.add('is-in'));
      return;
    }
    // Hidden state only applies once JS is running; a safety timer reveals everything regardless.
    document.documentElement.classList.add('js-reveal');
    const safety = window.setTimeout(() => els.forEach((el) => el.classList.add('is-in')), 2500);
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            en.target.classList.add('is-in');
            io.unobserve(en.target);
          }
        });
      },
      { rootMargin: '0px 0px -8% 0px', threshold: 0.05 },
    );
    els.forEach((el) => io.observe(el));
    return () => { io.disconnect(); window.clearTimeout(safety); };
  }, [dep]);
}
