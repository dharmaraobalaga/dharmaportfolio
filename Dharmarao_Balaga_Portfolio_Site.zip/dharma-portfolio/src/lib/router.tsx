import { createContext, useContext, useEffect, useState, type ReactNode, type AnchorHTMLAttributes } from 'react';

/**
 * Minimal hash router. Hash routing keeps every page deep-linkable on any static host
 * (no server rewrites needed) and lets the site run from a subfolder or a local file.
 */
export type Route = string;

const RouterCtx = createContext<Route>('/');

function readRoute(): Route {
  const h = window.location.hash.replace(/^#/, '');
  if (!h || !h.startsWith('/')) return '/';
  return h.split('?')[0] || '/';
}

export function RouterProvider({ children }: { children: ReactNode }) {
  const [route, setRoute] = useState<Route>(readRoute);
  useEffect(() => {
    const on = () => setRoute(readRoute());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return <RouterCtx.Provider value={route}>{children}</RouterCtx.Provider>;
}

export const useRoute = () => useContext(RouterCtx);

export const href = (to: Route) => `#${to}`;

export function navigate(to: Route) {
  if (readRoute() === to) {
    window.dispatchEvent(new HashChangeEvent('hashchange'));
  } else {
    window.location.hash = to;
  }
}

type LinkProps = AnchorHTMLAttributes<HTMLAnchorElement> & { to: Route };
export function Link({ to, onClick, ...rest }: LinkProps) {
  return (
    <a
      href={href(to)}
      onClick={(e) => {
        onClick?.(e);
        if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
        e.preventDefault();
        navigate(to);
      }}
      {...rest}
    />
  );
}

export const prefersReducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  el.scrollIntoView({ behavior: prefersReducedMotion() ? 'auto' : 'smooth', block: 'start' });
  // Move focus for keyboard and screen-reader users without a second jump.
  if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '-1');
  el.focus({ preventScroll: true });
}
