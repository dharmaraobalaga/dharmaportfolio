import { Hero } from '../components/Hero';
import { ProjectCard } from '../components/ProjectCard';
import { ProfileSection } from '../components/ProfileSection';
import { AIDesignPhilosophy } from '../components/AIDesignPhilosophy';
import { ContactSection } from '../components/ContactSection';
import { projects } from '../data/projects';
import { useDocumentTitle } from '../lib/useDocumentTitle';
import { useReveal } from '../lib/useReveal';

export function Home() {
  useDocumentTitle(
    'Dharmarao Balaga — Senior / Principal Product Designer',
    'Portfolio of Dharmarao Balaga (Dharma Rao), a Senior / Principal Product Designer and UX strategist in Hyderabad, India.',
  );
  useReveal('home');
  return (
    <>
      <Hero />
      <section id="work" className="section" aria-labelledby="work-title" style={{ paddingTop: 'clamp(48px, 6vw, 88px)' }}>
        <div className="wrap">
          <div className="sec-head">
            <div>
              <p className="eyebrow eyebrow--accent">Selected Work</p>
              <h2 id="work-title" className="h-2">Selected work</h2>
            </div>
            <p className="lede">
              Three projects. Three different challenges. One consistent approach: understand the problem, make
              deliberate design decisions, and build experiences people can trust.
            </p>
          </div>
          <div className="projects">
            {projects.map((p) => <ProjectCard key={p.slug} p={p} />)}
          </div>
        </div>
      </section>
      <ProfileSection />
      <AIDesignPhilosophy />
      <ContactSection />
    </>
  );
}
