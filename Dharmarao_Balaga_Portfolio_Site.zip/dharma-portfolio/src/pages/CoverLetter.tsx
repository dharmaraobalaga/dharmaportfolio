import { useState } from 'react';
import { site } from '../data/site';
import { Icon } from '../components/Icon';
import { Link } from '../lib/router';
import { useDocumentTitle } from '../lib/useDocumentTitle';

const paragraphs = [
  'I am writing to express my interest in Senior Product Designer, Principal Product Designer, and AI-focused product design opportunities.',
  'With nearly 20 years of experience across digital product design, UX strategy, visual communication, animation, and creative direction, I bring a combination of strategic thinking, hands-on design craft, and product leadership. I hold a Master of Design from IIT Bombay and have spent seven years leading product design at Openplay Technologies, part of the Nazara Group.',
  'At Openplay, I led product design initiatives and helped transform Classic Rummy from a legacy Flash experience into a modern mobile-first product. This work strengthened my expertise in interaction design, mobile UX, design systems, and cross-functional collaboration.',
  'Since founding D’SARAS Design Studio in 2025, I have continued working across product design consulting, mobile commerce, design systems, and AI-enabled workflows. My recent work explores how generative AI can accelerate ideation and prototyping, as well as how AI-powered products can remain transparent, usable, and trustworthy.',
  'I am particularly interested in opportunities where I can combine UX strategy, design leadership, and practical AI experience to solve complex problems and create meaningful product experiences.',
  'I would welcome the opportunity to discuss how my experience and approach could contribute to your team.',
  'Thank you for your time and consideration.',
];

const plainText = [
  'Dear Hiring Manager,',
  ...paragraphs,
  'Sincerely,\nDharmarao Balaga\nHyderabad, India\n' + site.email,
].join('\n\n');

export function CoverLetter() {
  useDocumentTitle('Cover Letter — Dharmarao Balaga', 'Cover letter from Dharmarao Balaga for Senior Product Designer, Principal Product Designer and AI-focused product design roles.');
  const [toast, setToast] = useState<string | null>(null);

  const flash = (msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 2200);
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(plainText);
      flash('Cover letter copied to clipboard');
    } catch {
      flash('Copy isn’t available in this browser. Select the text instead.');
    }
  };

  return (
    <>
      <section className="doc-head">
        <div className="wrap">
          <p className="eyebrow eyebrow--accent">Cover Letter</p>
          <h1 className="h-display">Cover Letter</h1>
          <p className="lede">Product Design · UX Strategy · AI-Driven Product Innovation</p>
          <div className="doc-tools">
            <a className="btn btn--primary" href={site.documents.coverLetter.href} download={site.documents.coverLetter.filename}>
              <Icon name="download" /> Download Cover Letter
            </a>
            <button type="button" className="btn btn--ghost" onClick={() => window.print()}>
              <Icon name="print" /> Print
            </button>
            <button type="button" className="btn btn--ghost" onClick={copy}>
              <Icon name="copy" /> Copy text
            </button>
          </div>
        </div>
      </section>
      <div className="wrap doc-layout">
        <article className="paper" aria-label="Cover letter">
          <header className="paper__head">
            <p className="paper__name">Dharmarao Balaga</p>
            <p className="paper__role">Product Design · UX Strategy · AI-Driven Product Innovation</p>
            <p className="paper__contact">
              <span>{site.location}</span>
              <a href={`mailto:${site.email}`}>{site.email}</a>
              <a href={site.linkedin} target="_blank" rel="noopener noreferrer">{site.linkedinLabel}</a>
              <a href={site.behance} target="_blank" rel="noopener noreferrer">{site.behanceLabel}</a>
            </p>
          </header>
          <div className="letter">
            <p>Dear Hiring Manager,</p>
            {paragraphs.map((p) => <p key={p.slice(0, 24)}>{p}</p>)}
            <div className="sign">
              <p>Sincerely,</p>
              <b>Dharmarao Balaga</b>
              <span>{site.location}</span>
              <span><a href={`mailto:${site.email}`}>{site.email}</a></span>
            </div>
          </div>
        </article>
        <aside className="doc-aside" aria-label="Cover letter actions">
          <div className="card">
            <span className="k">Download</span>
            <p>{site.documents.coverLetter.filename}<br /><span className="muted">{site.documents.coverLetter.size}</span></p>
            <a className="btn btn--dark" style={{ width: '100%' }} href={site.documents.coverLetter.href} download={site.documents.coverLetter.filename}>
              <Icon name="download" /> Download PDF
            </a>
          </div>
          <div className="card">
            <span className="k">Next</span>
            <p>Want the details behind the letter?</p>
            <div style={{ display: 'grid', gap: 10 }}>
              <Link to="/resume" className="btn btn--ghost">View Resume</Link>
              <a href={`mailto:${site.email}`} className="btn btn--ghost"><Icon name="mail" /> Contact Me</a>
            </div>
          </div>
        </aside>
      </div>
      {toast && <div className="toast" role="status">{toast}</div>}
    </>
  );
}
