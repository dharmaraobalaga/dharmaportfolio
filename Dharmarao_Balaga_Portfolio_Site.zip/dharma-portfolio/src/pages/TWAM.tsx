import { CaseHero, CaseFooter, Decision, HMW, Notice, Prototype, Section, SubNav, Swatches } from '../components/CaseStudy';
import { Figure, ProjectGallery } from '../components/ProjectGallery';
import { asset } from '../lib/asset';
import { useDocumentTitle } from '../lib/useDocumentTitle';

const img = (n: string) => asset(`images/twam/${n}.jpg`);
const PROTO = 'https://www.figma.com/make/TqlzaTuAIfLUywlKZFHwvD/Mobile-App-for-Twam';
const PLAY_STORE = 'https://play.google.com/store/apps/details?id=in.twam.app&hl=en_IN';
const P = { w: 403, h: 959 };

const nav = [
  { id: 'overview', label: 'Overview' },
  { id: 'users', label: 'Users' },
  { id: 'role', label: 'Role' },
  { id: 'research', label: 'Research' },
  { id: 'ia', label: 'IA & exploration' },
  { id: 'decisions', label: 'Decisions' },
  { id: 'final', label: 'Final UI' },
  { id: 'outcomes', label: 'Outcomes' },
];

const g = (items: [string, string, string][]) => items.map(([n, label, alt]) => ({ src: img(n), label, alt, caption: label, ...P }));

const groups = [
  { title: 'Onboarding: skippable, guest-friendly', items: g([
    ['onboarding-1', 'Comfort first', 'Onboarding 1: Essentials made for you'],
    ['onboarding-2', 'Private space to shop', 'Onboarding 2: Your private space to shop'],
    ['onboarding-3', 'Sign in or guest', 'Onboarding 3: Sign in or continue as guest'],
  ]) },
  { title: 'Discover: home, categories, search', items: g([
    ['home', 'Home', 'Home: search, hero and categories'],
    ['home-best-sellers', 'Best sellers, new arrivals', 'Home: best sellers and new arrivals'],
    ['home-care', 'TWAM Care', 'Home: TWAM Care brand promises'],
    ['listing-filters', 'Listing and filters', 'Listing with filter sheet for size and price'],
    ['search', 'Search', 'Search with suggestions and trending items'],
  ]) },
  { title: 'Product and fit', items: g([
    ['product', 'Product detail', 'Product detail: gallery, price and colours'],
    ['product-sizes', 'Sizes and details', 'Product detail: size grid and info sections'],
    ['fit-brand', 'Fit 2/4: brand', 'Size guide: select a brand'],
    ['fit-size', 'Fit 3/4: size', 'Size guide: select your size'],
    ['fit-result', 'Fit 4/4: result', 'Size guide result: your perfect size M'],
  ]) },
  { title: 'Buy, track, come back', items: g([
    ['cart', 'Cart', 'Cart with discreet packaging toggle'],
    ['checkout', 'Checkout', 'Checkout payment step with UPI selected'],
    ['track-order', 'Track order', 'Order tracking timeline'],
    ['notifications', 'Notifications', 'Notifications list'],
    ['my-twam', 'My TWAM', 'My TWAM profile with membership card'],
  ]) },
];

export function TWAM() {
  useDocumentTitle(
    'TWAM case study — Dharmarao Balaga',
    'TWAM: a mobile shopping app for OnlyTWAM designed around privacy and fit. Mobile commerce UX case study by Dharmarao Balaga.',
  );
  return (
    <>
      <CaseHero
        slug="twam"
        eyebrow="Case study 03"
        title="TWAM: shopping for intimate essentials, designed around privacy and fit"
        lede="A mobile app for OnlyTWAM, a premium Indian brand of innerwear, loungewear and everyday essentials. I set out to make buying a bra online feel like a quiet fitting room rather than a crowded sale aisle: guest browsing, fit help that starts from the size you already wear, and packaging nobody else can read."
        tags={[{ label: 'Shipped · Google Play · 20 Jun 2026', kind: 'status' }, { label: 'Mobile Commerce · E-commerce UX' }]}
        prototype={{ href: PROTO, label: 'Open the Figma Make prototype' }}
        extraLink={{ href: PLAY_STORE, label: 'Get it on Google Play' }}
        meta={[
          { k: 'Brand', v: 'OnlyTWAM · D’SARAS Design Studio' },
          { k: 'My role', v: 'Product designer, end to end: strategy, UX, UI, prototype' },
          { k: 'Platform', v: <>Android, <a href={PLAY_STORE} target="_blank" rel="noopener noreferrer">live on Google Play</a> · India</> },
          { k: 'Timeline', v: 'April – June 2026 · shipped 20 Jun 2026' },
          { k: 'Tools', v: 'Claude for early concepts, Figma Make (135 versions), Figma' },
        ]}
        notice={
          <Notice kind="info">
            <b>Live on Google Play since 20 June 2026.</b> Launch metrics aren’t published here. Personas and insights below
            came from desk research before launch and are labelled as hypotheses.
          </Notice>
        }
        media={
          <div style={{ background: 'var(--t-twam)', display: 'flex', justifyContent: 'center', gap: 'clamp(10px, 2.5vw, 32px)', padding: 'clamp(24px, 5vw, 64px) clamp(16px, 4vw, 56px) 0', overflow: 'hidden', maxHeight: 'clamp(300px, 46vw, 620px)' }}>
            {[['onboarding-2', 'Onboarding screen: Your private space to shop'], ['home', 'Home screen with search, New Season banner and category grid'], ['fit-result', 'Fit finder result: Your perfect size M'], ['cart', 'Cart with discreet packaging switched on']].map(([n, alt], i) => (
              <img key={n} src={img(n)} alt={alt} width={403} height={959}
                style={{ width: 'min(23%, 260px)', borderRadius: 18, boxShadow: '0 24px 48px rgb(86 44 54 / 16%)', border: '1px solid #e6dcd8', marginTop: i % 2 ? '6%' : 0 }}
                fetchPriority={i < 2 ? 'high' : undefined} />
            ))}
          </div>
        }
      />
      <SubNav items={nav} />

      <Section
        id="overview" n="01" label="Project overview"
        title="The hardest part of buying innerwear online isn’t the checkout"
        intro={
          <>
            <p>OnlyTWAM sells bras, panties, sleep and lounge sets, leakproof underwear, active and swimwear. Its tagline is “It’s all about you.” The app had to carry that promise into a category where most shopping apps feel loud: stacked discount banners, pop-ups, forced sign-up and catalogue pages built for volume.</p>
            <p><b>Problem.</b> A woman shopping for intimate essentials on her phone has two worries before price ever comes up: will it fit, and who will see what I bought. Generic marketplace patterns answer neither, so she either buys the size she always buys and hopes, or abandons the cart.</p>
            <p><b>Goal.</b> Design a calm, trust-first shopping app where she can browse without an account, get a size she trusts, and buy discreetly, in as few steps as a regular fashion app.</p>
          </>
        }
      >
        <div className="grid-3">
          <div className="card"><span className="k">Problem 1</span><h3>Fit uncertainty</h3><p>Bra sizing differs from brand to brand, and a tape measure is something most shoppers don’t have to hand mid-scroll.</p></div>
          <div className="card"><span className="k">Problem 2</span><h3>Privacy</h3><p>Shared phones, shared homes and branded parcels at the door make the purchase feel exposed long after the order is placed.</p></div>
          <div className="card"><span className="k">Problem 3</span><h3>Marketplace noise</h3><p>Pop-ups, countdown sales and forced log-in make a personal purchase feel pressured. A premium brand needs the opposite tone.</p></div>
        </div>
        <HMW>…help a woman find her size and buy intimate essentials privately, without making her sign up, measure herself or wade through promotions first?</HMW>
      </Section>

      <Section
        id="users" n="02" label="Target users"
        title="Three kinds of shopper, one shared need: confidence"
        intro={<p>Primary audience: women in urban India, roughly 20 to 45, who already shop for clothes on their phones and pay by UPI. These are proto-personas built from the brief and category knowledge. I have not interviewed shoppers yet, so treat them as hypotheses to test, not findings.</p>}
      >
        <div className="grid-3">
          {[
            ['The first-time online buyer', 'Has always bought innerwear in a shop. Curious, but unsure about size and uneasy about delivery.', ['Browse without an account', 'Size help in plain words', 'Proof the parcel is discreet']],
            ['The comfort re-buyer', 'Knows she’s a “34B in Enamor”. Wants to switch brands without gambling on the size, then reorder quickly.', ['Translate a size she already knows', 'A saved size profile', 'Fast reorder and tracking']],
            ['The function-first shopper', 'Buying active, swim or leakproof wear. Cares about fabric, support and care instructions more than trends.', ['Clear material and care details', 'Filter by size and price', 'Search by fabric or function']],
          ].map(([t, d, needs], i) => (
            <article className="persona" key={t as string}>
              <span className="eyebrow eyebrow--accent">Proto-persona {i + 1}</span>
              <h3 className="persona__name">{t as string}</h3>
              <p className="muted" style={{ fontSize: 'var(--fs-sm)' }}>{d as string}</p>
              <div className="card card--flat" style={{ padding: 0, border: 0 }}>
                <span className="k">Needs</span>
                <ul>{(needs as string[]).map((n) => <li key={n}>{n}</li>)}</ul>
              </div>
            </article>
          ))}
        </div>
      </Section>

      <Section
        id="role" n="03" label="My role"
        title="I owned the product design from brief to working prototype"
        intro={<p>I used AI tools to move fast: written briefs became code prototypes in Claude, then the build was refined over 135 saved versions in Figma Make. The tools generated; I decided what stayed.</p>}
      >
        <div className="grid-4">
          <div className="card"><h3>Strategy</h3><p>Brief, experience principles (“calm, private, trust-first”), what to leave out.</p></div>
          <div className="card"><h3>UX</h3><p>Proto-personas, journey, information architecture, fit-finder and checkout flows.</p></div>
          <div className="card"><h3>UI</h3><p>Visual direction, colour and type tokens, component set, 20+ screens.</p></div>
          <div className="card"><h3>Prototype</h3><p>AI-assisted build and iteration in Claude and Figma Make; self-audit of every flow.</p></div>
        </div>
      </Section>

      <Section
        id="research" n="04" label="Research & insights"
        title="Desk research first, and a clear list of what it can’t prove"
        intro={
          <>
            <p><b>What I did:</b> a pattern review of calm, well-structured retail apps (the UNIQLO app was the structural reference in the brief), and of how Indian innerwear brands present sizing. Those brands, such as Amante, Enamor and Soie, became the reference list in the fit finder.</p>
            <p><b>What I haven’t done yet:</b> interviews or usability sessions with real shoppers. Every insight below is labelled with how confident I am in it.</p>
          </>
        }
      >
        <div className="grid-2">
          {[
            ['Assumption · high', 'Shoppers remember a size, not a measurement', 'Starting fit help from “what you wear in another brand” asks less of her than a tape measure.'],
            ['Assumption · high', 'Forced log-in stops first visits', 'Asking for a phone number before showing products feels like a commitment she hasn’t decided to make.'],
            ['Assumption · medium', 'Discretion is a feature, not a footnote', 'Seeing “plain box, no brand outside” at the moment of paying should lower hesitation more than a line in the FAQ.'],
            ['Assumption · medium', 'UPI is the default way to pay', 'For this audience UPI should lead, with cash on delivery kept for first-time buyers who don’t yet trust the brand.'],
          ].map(([k, t, b]) => <div className="card" key={t}><span className="k">{k}</span><h3>{t}</h3><p>{b}</p></div>)}
        </div>

        <h3 className="h-5" style={{ margin: '44px 0 6px' }}>User journey: the first-time buyer</h3>
        <p className="muted" style={{ fontSize: 'var(--fs-sm)', marginBottom: 16 }}>Feelings and risks are hypothesised; the design response is what’s in the prototype.</p>
        <div className="table-wrap">
          <table className="t" style={{ minWidth: 900 }}>
            <thead><tr><th scope="col" /><th scope="col">1 · Arrive</th><th scope="col">2 · Browse</th><th scope="col">3 · Find fit</th><th scope="col">4 · Decide</th><th scope="col">5 · Pay</th><th scope="col">6 · Receive</th></tr></thead>
            <tbody>
              <tr><th scope="row">Doing</th><td>Opens the app from an ad or a friend’s tip</td><td>Scans categories and best sellers</td><td>Tries to work out her size in this brand</td><td>Reads fabric, care and returns</td><td>Reviews cart and pays</td><td>Waits for the parcel</td></tr>
              <tr><th scope="row">Feeling</th><td>Curious, guarded</td><td>Interested, easily overwhelmed</td><td>Anxious: “what if it doesn’t fit?”</td><td>Hopeful, still hesitant</td><td>Exposed: “who will see this?”</td><td>Impatient, private</td></tr>
              <tr><th scope="row">Risk</th><td>Sign-up wall, she leaves</td><td>Too many promos, feels cheap</td><td>Guesses, then returns it</td><td>Details buried, no trust</td><td>Branded parcel, abandons</td><td>No updates, calls support</td></tr>
              <tr><th scope="row">Design response</th><td>Skip on every onboarding step; “Continue as Guest”</td><td>One hero, six visual categories, size range on every card</td><td>4-step fit finder from a brand she knows</td><td>Collapsed sections for description, fabric, care, returns</td><td>Discreet packaging toggle in the cart; UPI first</td><td>Timeline tracking with a delivery window</td></tr>
            </tbody>
          </table>
        </div>
      </Section>

      <Section
        id="ia" n="05" label="IA & exploration"
        title="Four tabs, with shopping and fit always one tap away"
        intro={<p>The first brief had five tabs, including a separate Menu for categories. In the final build Menu is gone: the six categories sit on Home as a picture grid, Search covers the long tail, and the cart and search stay in the top bar on every main screen.</p>}
        wide={
          <>
            <div className="ia">
              <div className="ia__root">Splash <i>→</i> Onboarding ×3 (skippable) <i>→</i> Sign in / Register or Guest <i>→</i> Global: Search · Cart (top bar)</div>
              <div className="ia__cols">
                <div className="ia__col"><h4>Home</h4><ul><li>Hero carousel</li><li>Categories ×6 → Listing → Filters</li><li>Best sellers · New arrivals</li><li>Product → Size guide (4 steps)</li><li>TWAM Care (brand promises)</li></ul></div>
                <div className="ia__col"><h4>Wishlist</h4><ul><li>Products tab</li><li>Looks tab</li><li>Stock and quiet sale labels</li></ul></div>
                <div className="ia__col"><h4>Notifications</h4><ul><li>All · Messages · Orders</li><li>Back-in-stock in her size</li><li>Mark all read</li></ul></div>
                <div className="ia__col"><h4>My TWAM</h4><ul><li>Membership card</li><li>My Orders → Track order</li><li>Size profile</li><li>Saved addresses</li></ul></div>
              </div>
              <div className="ia__root" style={{ background: 'var(--c-surface-2)', color: 'var(--c-ink)' }}>Purchase flow: Cart (discreet toggle, coupon) <i style={{ color: 'var(--c-muted)' }}>→</i> Address <i style={{ color: 'var(--c-muted)' }}>→</i> Payment (UPI first) <i style={{ color: 'var(--c-muted)' }}>→</i> Confirm</div>
            </div>
            <h3 className="h-5" style={{ margin: '44px 0 16px' }}>How the direction changed between the first brief and version 135</h3>
            <div className="table-wrap">
              <table className="t">
                <thead><tr><th scope="col">Aspect</th><th scope="col">Exploration 1 · April brief</th><th scope="col">Final · Figma Make v135</th></tr></thead>
                <tbody>
                  <tr><th scope="row">Accent</th><td>Bright red #D72229 on buttons and headings</td><td>Deep burgundy #562C36: quieter, more premium</td></tr>
                  <tr><th scope="row">Ground</th><td>Warm ivory #FAF5F0 with blush and rose accents</td><td>Soft greige #F4F0ED, white cards, blush #F2D5D7 for chips and icons</td></tr>
                  <tr><th scope="row">Imagery</th><td>Flat lays and textures only, no models</td><td>Real people across skin tones and body types, plus flat lays for basics</td></tr>
                  <tr><th scope="row">Navigation</th><td>5 tabs: Home, Wishlist, Alerts, My TWAM, Menu</td><td>4 tabs; categories folded into Home and Search</td></tr>
                  <tr><th scope="row">Fit help</th><td>Step-by-step body measurement</td><td>Start from a brand and size she already wears</td></tr>
                </tbody>
              </table>
            </div>
          </>
        }
      />

      <Section
        id="decisions" full n="06" label="Key decisions"
        title="Six calls, what each one costs, and how sure I am"
        intro={<p>“Built” means it works in the prototype. “Hypothesis” means the reasoning is sound but no shopper has tested it yet.</p>}
      >
        <div>
          <Decision n={1} title="Guest first, account later" status="Built · impact is a hypothesis" phone
            tradeoff="the brand learns less about her early, and personalisation starts later."
            media={<Figure src={img('onboarding-3')} {...P} alt="Onboarding step 3 with Sign In / Register and Continue as Guest" />}>
            <p>Every onboarding slide has Skip, and the last offers “Continue as Guest” next to Sign in.</p>
          </Decision>
          <Decision n={2} title="Fit from a size she knows" status="Flow built · logic is a placeholder" phone
            tradeoff="faster than measuring, but only as good as the brand-to-brand size data behind it, which doesn’t exist yet."
            media={<Figure src={img('fit-brand')} {...P} alt="Size guide step 2: select a brand" />}>
            <p>The size guide asks for category, a brand she wears and her size there, then gives a TWAM size and a “Shop size M” shortcut.</p>
          </Decision>
          <Decision n={3} title="Discretion where she pays" status="Built · impact is a hypothesis" phone
            tradeoff="plain boxes give up the unboxing moment a premium brand might want, and add an operational promise."
            media={<Figure src={img('cart')} {...P} alt="Cart with discreet packaging toggle switched on" />}>
            <p>“Discreet packaging: plain box, no brand outside” is a toggle in the cart, on by default, not a setting buried in the profile.</p>
          </Decision>
          <Decision n={4} title="Size range on every product card" status="Built" phone
            tradeoff="one more line on a small card, and ratings drop off the listing view."
            media={<Figure src={img('listing')} {...P} alt="Product listing with size ranges on cards" />}>
            <p>Listing cards show “XS–XL” or “30B–40DD” under the name, so she doesn’t open products that can’t fit her.</p>
          </Decision>
          <Decision n={5} title="Quiet commerce" status="Built · impact is a hypothesis" phone
            tradeoff="fewer promotional surfaces than a typical sale-driven app. Strike-through prices remain, as a compromise with the business."
            media={<Figure src={img('wishlist')} {...P} alt="Wishlist with subtle in-stock and sale labels" />}>
            <p>No pop-ups or countdowns. Offers live in one hero slot and one notification; wishlist sale labels are small text, not badges.</p>
          </Decision>
          <Decision n={6} title="UPI first, COD kept" status="Built" phone
            tradeoff="COD means more cancelled orders and returns, but removes the biggest trust barrier for a new brand."
            media={<Figure src={img('checkout')} {...P} alt="Checkout payment step with UPI selected" />}>
            <p>A three-step checkout (Address, Payment, Confirm) opens on UPI, with cards, net banking and cash on delivery below.</p>
          </Decision>
        </div>
      </Section>

      <Section
        id="final" n="07" label="Final UI & design system"
        title="One clickable prototype, every core flow"
        intro={
          <>
            <p>Every screen below is a capture from the Figma Make build (version 135): onboarding, browsing, the size guide, cart, checkout, tracking and profile all work in the prototype.</p>
            <p className="muted" style={{ fontSize: 'var(--fs-sm)' }}>Onboarding and some product photos in these captures were refreshed with free-licence Unsplash photography after the build; the live prototype still shows the earlier images. The app on Google Play may differ in detail from these prototype captures.</p>
          </>
        }
        wide={
          <>
            {groups.map((gr) => (
              <div className="gallery-group" key={gr.title}>
                <h3>{gr.title}</h3>
                <ProjectGallery layout="phones" items={gr.items} />
              </div>
            ))}
            <Prototype href={PROTO} title="Figma Make prototype · v135" body="Tap through onboarding, browsing, the size guide, cart, checkout, tracking and profile." cta="Open in Figma Make" />
            <div className="grid-2" style={{ marginTop: 56, gap: 32, alignItems: 'start' }}>
              <div>
                <h3 className="h-5" style={{ marginBottom: 16 }}>Colour (sampled from the build)</h3>
                <Swatches colors={[{ hex: '#562C36', name: 'Burgundy', note: 'actions' }, { hex: '#F4F0ED', name: 'Greige', note: 'ground' }, { hex: '#FFFFFF', name: 'White', note: 'cards' }, { hex: '#F2D5D7', name: 'Blush', note: 'chips' }, { hex: '#EAE0DE', name: 'Shell', note: 'secondary' }]} />
              </div>
              <div>
                <h3 className="h-5" style={{ marginBottom: 16 }}>Type, shape &amp; components</h3>
                <ul className="list-rows">
                  <li><span>Type</span><span>Section titles 18–20 semibold; body 15–16 regular; eyebrows 12 caps, tracked. Clean sans throughout (Urbanist in the first exploration).</span></li>
                  <li><span>Radii</span><span>12 on buttons and size pills, 16 on cards, 24 on sheets.</span></li>
                  <li><span>Components</span><span>Primary &amp; soft buttons · size pills &amp; swatches · product card · numbered stepper · accordion rows · toggle row &amp; radio cards · filter sheet · tracking timeline · notification card · tabs &amp; chips · membership card · 4-tab bottom navigation</span></li>
                </ul>
              </div>
            </div>
          </>
        }
      />

      <Section
        id="outcomes" n="08" label="Outcomes & lessons"
        title="Shipped in June 2026. Here’s what I know so far."
        intro={<p>TWAM went live on Google Play on 20 June 2026. I’m not publishing conversion or return numbers here, so this section covers the prototype audit I ran before launch and how each open bet can now be measured with real shoppers.</p>}
      >
        <div className="grid-3" style={{ alignItems: 'start' }}>
          <div className="card">
            <span className="k">Validated · by walking every flow in v135</span>
            <ul className="checks">
              <li>Guest can go from first launch to payment without an account</li>
              <li>Fit finder completes in 4 steps and links straight to “Shop size M”</li>
              <li>Discreet packaging is visible and on by default before checkout</li>
              <li>Checkout is 3 clear steps; tracking shows a live stage and delivery window</li>
              <li>Core screens share one colour, type and component system</li>
            </ul>
          </div>
          <div className="card">
            <span className="k">Gaps found in my pre-launch audit of v135</span>
            <ul className="checks gaps">
              <li>Fit finder offers XS–4XL for bras, while the product page uses band and cup (34B)</li>
              <li>The fit result repeats the size entered; no real brand mapping yet</li>
              <li>Every product card opens the same product page</li>
              <li>Cart summary has no explicit order total line</li>
              <li>Cart badge count differs between screens; one category image loads late</li>
            </ul>
          </div>
          <div className="card">
            <span className="k">Still hypotheses · now measurable with live users</span>
            <ul className="checks hyp">
              <li><b>Guest-first lifts first orders.</b> A/B against a log-in gate; measure first-session checkout starts.</li>
              <li><b>Brand-based fit cuts size returns.</b> Track return reasons for fit-finder users vs. others.</li>
              <li><b>Discreet default builds trust.</b> 6–8 moderated sessions; ask what made them hesitate.</li>
              <li><b>Quiet UI reads as premium.</b> Five-second and preference tests against a promo-heavy variant.</li>
            </ul>
          </div>
        </div>
        <h3 className="h-5" style={{ margin: '40px 0 16px' }}>Lessons</h3>
        <ul className="list-rows">
          <li><span>AI makes screens cheap; consistency isn’t</span><span>135 versions moved fast, but each generation could quietly break something elsewhere, like the size mismatch. I now keep a short checklist of invariants and re-walk core flows after every few versions.</span></li>
          <li><span>Model the data before the UI</span><span>The fit finder looks finished but has no size table behind it. Next time I’d define the sizing model (band, cup, letter, brand mapping) first and design the flow on top of it.</span></li>
          <li><span>Privacy is a design surface</span><span>Putting discretion in the cart, onboarding and notifications did more for the brand’s tone than any colour choice.</span></li>
          <li><span>Test with people sooner</span><span>My biggest bets rest on assumptions. A handful of conversations in week one would have told me which ones to build first.</span></li>
        </ul>
        <h3 className="h-5" style={{ margin: '40px 0 16px' }}>Next steps</h3>
        <ul className="list-rows">
          <li><span>1 · Fix</span><span>Work through the audit list, starting with a real bra size model and per-product pages.</span></li>
          <li><span>2 · Test</span><span>Run 6–8 moderated sessions with first-time and repeat buyers on the fit and checkout flows.</span></li>
          <li><span>3 · Measure</span><span>Agree success metrics with the brand: checkout start rate, fit-finder completion, size-related returns.</span></li>
        </ul>
      </Section>

      <CaseFooter slug="twam" />
    </>
  );
}
