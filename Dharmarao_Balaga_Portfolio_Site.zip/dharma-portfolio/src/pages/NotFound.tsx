import { Link } from '../lib/router';
import { useDocumentTitle } from '../lib/useDocumentTitle';

export function NotFound() {
  useDocumentTitle('Page not found — Dharmarao Balaga');
  return (
    <section className="notfound">
      <div className="wrap">
        <p className="eyebrow eyebrow--accent">404</p>
        <h1 className="h-2" style={{ margin: '16px 0 20px' }}>This page doesn’t exist.</h1>
        <p className="lede">The link may be out of date. The selected work and resume are a click away.</p>
        <div className="btn-row" style={{ marginTop: 28 }}>
          <Link to="/" className="btn btn--primary">Go to homepage</Link>
          <Link to="/work" className="btn btn--ghost">Selected Work</Link>
        </div>
      </div>
    </section>
  );
}
