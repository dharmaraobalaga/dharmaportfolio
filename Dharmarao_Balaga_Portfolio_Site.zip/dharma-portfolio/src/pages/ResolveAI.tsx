import { CaseHero, CaseFooter, Decision, HMW, Notice, Persona, Prototype, Section, SubNav, Swatches } from '../components/CaseStudy';
import { Figure, ProjectGallery } from '../components/ProjectGallery';
import { asset } from '../lib/asset';
import { useDocumentTitle } from '../lib/useDocumentTitle';

const img = (n: string) => asset(`images/resolveai/${n}.jpg`);
const PROTO = 'https://claude.ai/artifact/8A5vvbdMmB5Pnpqrit4yB9';

const nav = [
  { id: 'overview', label: 'Overview' },
  { id: 'users', label: 'Users' },
  { id: 'role', label: 'Role' },
  { id: 'research', label: 'Research' },
  { id: 'ia', label: 'IA & exploration' },
  { id: 'decisions', label: 'Decisions' },
  { id: 'final', label: 'Final UI' },
  { id: 'outcomes', label: 'Outcomes' },
];

const screens = [
  { src: img('overview'), label: 'Overview · SLA risk first, AI review rates alongside', alt: 'Overview dashboard with KPI tiles, ticket trend, priority and SLA charts, AI review metrics, activity and SLA risk queue', w: 1776, h: 1333 },
  { src: img('ticket'), label: 'Ticket details · the audit trail separates AI from people', alt: 'Ticket details page with resolution, internal notes, audit trail, SLA and escalation', w: 1776, h: 1709, tall: true },
  { src: img('analytics'), label: 'Analytics · AI Quality: acceptance, edits and failure trends', alt: 'Analytics page with summary metrics, charts, SLA table, CSAT and AI Quality section', w: 1776, h: 1848, tall: true },
  { src: img('kb'), label: 'Knowledge Base · only Approved articles are citable', alt: 'Knowledge Base with article statuses and which articles AI may cite', w: 1776, h: 1235 },
].map((x) => ({ ...x, caption: x.label }));

const boards = [
  { src: img('states'), label: 'AI states & guardrails board', alt: 'AI states and guardrails board with principles, four failure states and supporting states', w: 1776, h: 2025, tall: true },
  { src: img('ds'), label: 'Design system foundations & components', alt: 'Design system board with colour tokens, typography, spacing, components and accessibility rules', w: 1776, h: 2345, tall: true },
].map((x) => ({ ...x, caption: x.label }));

const hax: [string, string][] = [
  ['G1 · Make clear what the system can do', '“AI-generated” labels; “AI never sends replies or takes actions”'],
  ['G2 · Make clear how well it can do it', 'Intent confidence; a “Not known” callout for missing facts'],
  ['G8 · Support efficient dismissal', 'Dismiss, with Restore'],
  ['G9 · Support efficient correction', 'Insert & edit; summary correction'],
  ['G10 · Scope services when in doubt', '“Not enough information”: no draft, a clarifying question instead'],
  ['G11 · Make clear why', 'Numbered source citations on each sentence'],
  ['G15 · Encourage granular feedback', 'Report on summaries and suggestions'],
  ['G16 · Convey consequences', 'Confirmation dialog before opening a carrier trace'],
];

export function ResolveAI() {
  useDocumentTitle(
    'ResolveAI case study — Dharmarao Balaga',
    'ResolveAI: a self-initiated concept for an AI copilot that customer-support agents can check, correct and overrule. Human-in-the-loop AI product design by Dharmarao Balaga.',
  );
  return (
    <>
      <CaseHero
        slug="resolveai"
        eyebrow="Case study 02"
        title="ResolveAI: an AI copilot that support agents can check, correct and overrule"
        lede="A desktop support platform where AI drafts, summarises and suggests, but never sends or acts on its own. I designed it around the moments AI is most likely to fail: thin data, invented facts and outages."
        tags={[{ label: 'Self-initiated concept · 2026', kind: 'concept' }, { label: 'B2B SaaS · AI Product Design' }]}
        prototype={{ href: PROTO, label: 'Open the interactive prototype' }}
        meta={[
          { k: 'Type', v: 'Self-initiated portfolio concept' },
          { k: 'My role', v: 'Sole product designer: framing to prototype' },
          { k: 'Timeline', v: '2026' },
          { k: 'Platform', v: 'Desktop web · 1440 first' },
          { k: 'Team', v: 'Solo, with AI-assisted tooling' },
        ]}
        notice={
          <Notice>
            <b>A concept, not a shipped product.</b> ResolveAI, its customer Northwind Retail and every person and number on
            these screens are fictional. Nothing here has been tested with real support agents yet, so Outcomes separates
            what I checked from what is still a hypothesis.
          </Notice>
        }
        media={
          <div style={{ background: 'var(--t-resolve)', padding: 'clamp(16px, 4vw, 56px)' }}>
            <img src={img('inbox')} alt="ResolveAI inbox: ticket list, Sarah Johnson’s conversation and the AI Copilot panel with a labelled summary, intent confidence, approved sources and a Not known callout" width={1776} height={1235} style={{ borderRadius: 10, boxShadow: '0 24px 60px rgb(14 26 51 / 16%)', border: '1px solid #d6dbe6' }} fetchPriority="high" />
          </div>
        }
      />
      <SubNav items={nav} />

      <Section
        id="overview" n="01" label="Overview & problem"
        title="AI makes replies faster. It also makes wrong replies easier to send."
        intro={
          <>
            <p>Support platforms now routinely offer AI summaries and suggested replies. The appeal is obvious: agents under SLA pressure get a draft in seconds. The risk is less visible. A fluent draft reads like the truth, and a busy agent can send it without checking.</p>
            <p>My test case was a single ordinary ticket. Sarah Johnson writes: “My order has not arrived.” The easy AI answer invents a tracking update and promises a delivery date. Neither is known. If that reply goes out, the company has made a promise it can’t keep, and the agent is the one accountable for it.</p>
          </>
        }
      >
        <div className="grid-3">
          <div className="card"><span className="k">Objective 1</span><p>Cut the time from opening a ticket to a confident first reply.</p></div>
          <div className="card"><span className="k">Objective 2</span><p>Make it impossible for an unsupported claim to reach a customer unnoticed.</p></div>
          <div className="card"><span className="k">Objective 3</span><p>Keep the inbox fully usable when the AI is uncertain or down.</p></div>
        </div>
        <HMW>…give support agents the speed of AI drafting while keeping every fact, promise and action under their control, including when the AI is wrong or unavailable?</HMW>
      </Section>

      <Section
        id="users" n="02" label="Target users"
        title="Three roles, one question: can I trust what the AI just did?"
        intro={<p>These are proto-personas, built from the brief and my assumptions about support work, not from interviews. They exist to make trade-offs concrete and are the first thing I’d test with real agents.</p>}
      >
        <div className="grid-3">
          <Persona tag="Primary · Support agent" name="Ravi Menon" sub="Tier 2 agent · 40–60 tickets a day"
            quote="If the draft is right I want to send it fast. If it’s wrong, I need to see that before the customer does."
            rows={[['Needs', 'Context at a glance, drafts that cite facts, one-step edits.'], ['Fears', 'Being blamed for a promise the AI made.']]} />
          <Persona tag="Secondary · Team lead" name="Lena Ortiz" sub="Leads a shipping-issues team of 9"
            quote="I need to see which tickets are about to breach, and who — person or AI — did what on each one."
            rows={[['Needs', 'SLA risk queue, escalation control, a clear audit trail.'], ['Fears', 'Silent AI errors repeated across the team.']]} />
          <Persona tag="Secondary · CX manager" name="Head of CX" sub="Owns AI rollout, CSAT and SLA targets"
            quote="Is the AI actually helping, and where is it failing us?"
            rows={[['Needs', 'Acceptance and edit rates, error trends, outage impact.'], ['Fears', 'Buying speed at the cost of customer trust.']]} />
        </div>
        <p className="muted" style={{ marginTop: 20, fontSize: 'var(--fs-sm)', maxWidth: '66ch' }}>And the person who never logs in: Sarah, the customer. She is not a user of ResolveAI, but every guardrail exists to protect what she is told.</p>
      </Section>

      <Section
        id="role" n="03" label="My role"
        title="Solo, end to end, with AI as a production tool, not the designer"
        intro={
          <>
            <p>I set the problem, the guardrail rules and the quality bar. I worked without a PM or engineers, so the decisions below are mine to defend.</p>
            <p>How I used AI: I wrote a detailed brief and guardrail spec, used an AI design tool to produce the screens, then reviewed every state against that spec and revised it.</p>
          </>
        }
      >
        <div className="grid-3">
          {[
            ['Problem framing', 'Scope, success criteria and the sample ticket that tests them.'],
            ['Guardrail spec', 'What the AI may draft, suggest or do, and what needs a person.'],
            ['IA & flows', 'Navigation, the three-column inbox and the agent journey.'],
            ['UI & AI states', 'Eight screens plus loading, empty, error and failure states.'],
            ['Design system', 'Tokens, components and contrast-checked colour pairs.'],
            ['Prototype & review', 'Clickable flow, accessibility review and this write-up.'],
          ].map(([k, v]) => <div className="card" key={k}><h3>{k}</h3><p>{v}</p></div>)}
        </div>
      </Section>

      <Section
        id="research" n="04" label="Research & insights"
        title="The hard part isn’t generating a reply. It’s knowing when not to trust one."
        intro={<p>This was desk research, not fieldwork. I worked from the brief, established human–AI interaction guidance (Microsoft’s HAX guidelines and Google PAIR’s People + AI Guidebook), WCAG 2.2, and a review of AI features in mainstream help-desk tools. The insights below are working assumptions to test.</p>}
      >
        <div className="grid-2">
          {[
            ['Errors cost more than speed saves', 'One invented delivery date undoes the goodwill of many fast replies. Accuracy has to win when the two conflict.'],
            ['Over-trust is the quiet failure', 'Automation bias means fluent drafts get skimmed. The UI should slow agents down at the risky moment, not every moment.'],
            ['Agents need the “why” in place', 'Sources and confidence must sit beside the draft. If checking means opening another tool, it won’t happen under SLA pressure.'],
            ['Failure is a normal state', 'Thin data, wrong summaries and outages will happen. The inbox has to work fully without the AI.'],
          ].map(([t, b], i) => <div className="card" key={t}><span className="num">0{i + 1}</span><h3>{t}</h3><p>{b}</p></div>)}
        </div>

        <h3 className="h-5" style={{ margin: '44px 0 16px' }}>Microsoft HAX guidelines I designed against, and where they show up</h3>
        <div className="table-wrap">
          <table className="t">
            <thead><tr><th scope="col">Guideline</th><th scope="col">Where it shows up in ResolveAI</th></tr></thead>
            <tbody>{hax.map(([g, w]) => <tr key={g}><th scope="row">{g}</th><td>{w}</td></tr>)}</tbody>
          </table>
        </div>

        <h3 className="h-5" style={{ margin: '44px 0 16px' }}>Agent journey: Sarah’s ticket, where the risk sits, and the design response</h3>
        <div className="journey">
          <div><h4>Triage</h4><p className="risk">Missing a ticket about to breach.</p><p className="resp">SLA-risk queue sorted by due time, one click into the conversation.</p></div>
          <div><h4>Understand</h4><p className="risk">A wrong summary taken as fact.</p><p className="resp">Labelled summary with “Is this accurate?” and Report.</p></div>
          <div><h4>Draft</h4><p className="risk">Invented tracking or dates.</p><p className="resp">Cite-or-remove, plus a “Not known” box.</p></div>
          <div><h4>Act</h4><p className="risk">The draft promises an action nobody took.</p><p className="resp">AI suggests the trace; the agent confirms it.</p></div>
          <div><h4>Send</h4><p className="risk">Sending unread.</p><p className="resp">Review checkbox, explicit Send, then Undo.</p></div>
          <div><h4>Follow up</h4><p className="risk">No record of who did what.</p><p className="resp">Status change, SLA pause and an audit trail split into AI and people.</p></div>
        </div>
      </Section>

      <Section
        id="ia" n="05" label="IA & exploration"
        title="Organised around work, then knowledge, then insight"
        intro={<p>Agents live in the top group; leads and managers move down into Insights. AI Quality gets its own entry rather than hiding inside Analytics, because reviewing AI errors is a daily job, not a quarterly report.</p>}
        wide={
          <>
            <div className="ia">
              <div className="ia__root">Global bar <i>·</i> search <i>·</i> workspace <i>·</i> notifications <i>·</i> help <i>·</i> profile</div>
              <div className="ia__cols">
                <div className="ia__col"><h4>Work</h4><ul><li>Overview</li><li>Inbox</li><li>My Tickets</li><li>All Tickets</li><li className="sub">↳ Ticket → details &amp; audit</li></ul></div>
                <div className="ia__col"><h4>Knowledge</h4><ul><li>Customers</li><li>Knowledge Base</li><li className="sub">↳ Approved articles are the only sources AI may cite</li></ul></div>
                <div className="ia__col"><h4>Insights</h4><ul><li>Analytics</li><li>AI Quality</li><li className="sub">↳ Reports, error review, outage log</li></ul></div>
                <div className="ia__col"><h4>Settings</h4><ul><li>AI policies &amp; allowed actions</li><li>SLA rules</li><li>Roles &amp; permissions</li><li>Data masking</li></ul></div>
              </div>
            </div>
            <h3 className="h-5" style={{ margin: '44px 0 16px' }}>Where should the AI live? Three options</h3>
            <div className="options">
              <div className="card"><span className="verdict">Rejected</span><h3>A · Auto-draft in composer</h3><p>Fastest path, but AI text looks like the agent’s own and is one keystroke from sent. It invites exactly the over-trust I was designing against.</p></div>
              <div className="card is-chosen"><span className="verdict">Chosen</span><h3>B · Side panel, explicit insert</h3><p>Evidence and draft sit side by side with the conversation. Nothing enters the composer until the agent chooses Insert &amp; edit.</p></div>
              <div className="card"><span className="verdict">Rejected</span><h3>C · Separate AI view or modal</h3><p>Keeps AI clearly separate, but hides the thread while drafting. Checking a draft against the customer’s words means switching back and forth.</p></div>
            </div>
            <h3 className="h-5" style={{ margin: '44px 0 16px' }}>Inbox anatomy: three working columns beside the navigation</h3>
            <div className="grid-4">
              <div className="card"><span className="k">1 · Navigation</span><p>Persistent, with queue counts and an AI Quality badge.</p></div>
              <div className="card"><span className="k">2 · Ticket list</span><p>Search, filter chips, sort by SLA. Priority and SLA shown as text badges.</p></div>
              <div className="card"><span className="k">3 · Conversation</span><p>The agent’s space. AI text only arrives when the agent inserts it, and stays labelled.</p></div>
              <div className="card"><span className="k">4 · Copilot · Customer</span><p>Summary, intent, sources, suggested action and reply. A tab switches to customer context.</p></div>
            </div>
          </>
        }
      />

      <Section id="decisions" full n="06" label="Key decisions" title="Six calls that put the agent in charge">
        <div>
          <Decision n={1} title="Show the evidence before the draft"
            tradeoff="the reply sits lower in the panel, one scroll away. I accepted a slightly slower path to the draft in exchange for context that’s hard to skip.">
            <p>The Copilot panel reads top to bottom as summary → intent → sources → what isn’t known → suggested action → reply. By the time an agent reaches the draft, they already know what it should and shouldn’t say.</p>
          </Decision>
          <Decision n={2} title="Cite it or remove it"
            tradeoff="drafts are shorter and less smooth, and showing the AI’s mistakes could lower trust. I think that’s the right kind of trust: calibrated, not blind."
            media={
              <div className="mock-ui" role="img" aria-label="Example: one sentence removed from an AI draft as an unsupported claim">
                <span className="removed">1 sentence removed · unsupported claim</span>
                <p className="strike">“Your chair will arrive by Thursday, 29 October.”</p>
                <p className="muted" style={{ marginTop: 6 }}>No approved source supports a delivery date.</p>
              </div>
            }>
            <p>Every sentence in a suggestion carries a source number. A sentence with no approved source is stripped before display, then shown struck through with the reason, so the agent sees what the AI tried to say.</p>
          </Decision>
          <Decision n={3} title="A review gate, only for AI-assisted replies"
            tradeoff="one extra click, and a risk of checkbox fatigue. That risk is the first thing I’d test (see Outcomes)."
            media={
              <div className="mock-ui" role="img" aria-label="Example: review checkbox that must be ticked before an AI-assisted reply can be sent">
                <p style={{ display: 'flex', gap: 10, alignItems: 'center' }}><span aria-hidden="true" style={{ width: 18, height: 18, border: '1.5px solid var(--c-line-strong)', borderRadius: 4, display: 'inline-block' }} />I’ve reviewed this AI-assisted reply for accuracy</p>
                <p style={{ marginTop: 12, display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}><span className="btn btn--ghost" aria-hidden="true" style={{ minHeight: 36, padding: '6px 14px', opacity: .55 }}>Send reply</span><span className="muted">Unavailable until you confirm your review.</span></p>
              </div>
            }>
            <p>If a reply started from an AI draft, Send stays disabled until the agent ticks “I’ve reviewed”. The reason is always written next to the button. Replies written from scratch skip the gate.</p>
          </Decision>
          <Decision n={4} title="AI suggests actions; people take them"
            tradeoff="slower than one-click automation. Admins decide in Settings › AI policies which low-risk, reversible actions (like auto-tagging) may run automatically; those are logged, so the friction only applies where it matters."
            media={<Figure src={img('policies')} w={1776} h={1353} alt="Settings, AI policies page listing what Copilot may do automatically, may only suggest, and may never do" caption="Settings › AI policies: what runs automatically, what only gets suggested, and what is locked" />}>
            <p>Copilot can recommend opening a UPS trace but can’t open one. The agent confirms in a dialog that states what will happen and who is accountable. If the draft says “I’ve opened a trace” before one exists, Send is blocked until that’s fixed.</p>
          </Decision>
          <Decision n={5} title="Private by default"
            tradeoff="an extra step when agents need contact details, and a less personalised AI draft. Worth it for data that should never leave the system."
            media={<Figure src={img('customer')} w={1776} h={1265} alt="Customer profile for Sarah Johnson with masked email and phone and a logged Reveal action" caption="Customer profile: contact details masked by default; every reveal is logged" />}>
            <p>Customer email and phone are masked; revealing them is one click, and the reveal is written to the audit log. Payment details and full addresses are never sent to the model, and the panel says so.</p>
          </Decision>
          <Decision n={6} title="Design failure as a first-class state"
            tradeoff="four failure states to design, build and maintain instead of one generic error. I prioritised them over extra screens."
            media={
              <div className="grid-2" style={{ gap: 12 }}>
                <Figure src={img('insufficient-panel')} w={470} h={820} alt="Copilot panel: Not enough information to draft a reliable reply, listing what is missing and offering a clarifying question" caption="Insufficient information" />
                <Figure src={img('outage-panel')} w={470} h={820} alt="Copilot panel: AI Copilot is unavailable, with Retry, Write reply manually and an approved macro" caption="AI outage" />
              </div>
            }>
            <p>When data is thin, the AI drafts nothing and lists what’s missing. When the service is down, the panel says so plainly and offers Retry, a manual path and an approved macro. The inbox, composer and Send keep working, and drafts are never lost.</p>
          </Decision>
        </div>
      </Section>

      <Section
        id="final" n="07" label="Final UI & design system"
        title="Calm, dense and honest about what’s AI"
        intro={<p>A light, flat workspace built for eight-hour shifts: navy text, one blue for actions, and violet reserved for AI-generated content. No gradients or oversized cards; everything earns its space.</p>}
        wide={
          <>
            <ProjectGallery layout="wide" items={screens} />
            <Prototype href={PROTO} title="Interactive prototype"
              body="Path: Overview SLA-risk row → Sarah’s ticket → read summary & sources → Insert & edit draft → confirm UPS trace → tick review → Send → Undo. You can simulate an AI outage at any point."
              cta="Open the prototype" />
            <div className="gallery-group">
              <h3 style={{ marginTop: 56 }}>Guardrails &amp; system boards</h3>
              <ProjectGallery layout="wide" items={boards} />
            </div>
            <div className="grid-2" style={{ marginTop: 48, gap: 32, alignItems: 'start' }}>
              <div>
                <h3 className="h-5" style={{ marginBottom: 16 }}>Colour</h3>
                <Swatches colors={[{ hex: '#F5F7FA', name: 'Surface' }, { hex: '#1D4ED8', name: 'Action' }, { hex: '#5B3CC4', name: 'AI only' }, { hex: '#0B6E3F', name: 'Success' }, { hex: '#8A4B00', name: 'Warning' }, { hex: '#B42318', name: 'Error' }]} />
                <p className="muted" style={{ marginTop: 14, fontSize: 'var(--fs-sm)' }}>Semantic colours are always paired with an icon and a word, never colour alone.</p>
              </div>
              <div>
                <h3 className="h-5" style={{ marginBottom: 16 }}>Type, spacing &amp; components</h3>
                <ul className="list-rows">
                  <li><span>Inter</span><span>32 · 24 · 18 · 15 · 14 · 13 · 12</span></li>
                  <li><span>4 / 8 px grid</span><span>Radius 4 · 6 · 8 · 12 · flat cards, shadow only on overlays</span></li>
                  <li><span>Components</span><span>Buttons · inputs · badges · chips · tabs · tables · alerts · dialogs · toasts</span></li>
                  <li><span>Contrast</span><span>Every text-and-background pair checked at 5.25:1 or higher (WCAG 2.2 AA needs 4.5:1).</span></li>
                </ul>
              </div>
            </div>
          </>
        }
      />

      <Section
        id="outcomes" n="08" label="Outcomes & lessons"
        title="What I checked, what I’m betting on, what I’d test next"
        intro={<p>There are no real-world results to report: this is a concept. The numbers on the dashboards are illustrative sample data, not outcomes.</p>}
      >
        <div className="grid-2" style={{ gap: 20, alignItems: 'start' }}>
          <div className="card">
            <span className="k">Checked · design review by me, not user testing</span>
            <ul className="checks">
              <li>Contrast: every text pair in the system measured at 5.25:1 or higher against WCAG 2.2 AA.</li>
              <li>Colour-blind safety: chart colours run through a colour-vision-deficiency checker.</li>
              <li>Not colour alone: status, priority, SLA and AI content all carry a text label or icon.</li>
              <li>Coverage: the sample ticket runs end to end in the prototype, and all four AI failure states have a working way forward.</li>
              <li>Keyboard &amp; semantics: native controls, visible focus, labelled icon buttons, live-region feedback.</li>
            </ul>
          </div>
          <div className="card">
            <span className="k">Hypotheses · not yet tested, and how I’d measure each</span>
            <ul className="checks hyp">
              <li><b>H1 · The review gate catches errors without slowing agents much.</b> Seeded errors caught, and time-to-send, with and without the gate.</li>
              <li><b>H2 · Inline sources lead to better-calibrated trust.</b> Accept/edit decisions on drafts with and without a planted unsupported claim.</li>
              <li><b>H3 · Cite-or-remove keeps unsupported claims out of sent replies.</b> Audit a sample of sent AI-assisted replies. Target: none.</li>
              <li><b>H4 · Agents stay within SLA during an AI outage.</b> First-response time in a simulated outage versus normal operation.</li>
            </ul>
          </div>
        </div>
        <div className="card" style={{ marginTop: 20 }}>
          <span className="k">Validation plan · next step (not yet run)</span>
          <ul className="list-rows" style={{ borderTop: 0 }}>
            <li><span>Who</span><span>5–6 working support agents and 1–2 team leads.</span></li>
            <li><span>Tasks</span><span>Handle Sarah’s ticket; handle a ticket with a seeded wrong claim; keep working through a simulated outage.</span></li>
            <li><span>Pass if</span><span>Every seeded error is caught before send, no task is abandoned at the review gate, and agents can explain where each fact came from.</span></li>
          </ul>
        </div>
        <h3 className="h-5" style={{ margin: '40px 0 16px' }}>Lessons</h3>
        <ul className="list-rows">
          <li><span>Design the failure first</span><span>Starting from “what if the AI is wrong?” shaped the happy path more than any feature idea did.</span></li>
          <li><span>Calibrate trust, don’t maximise it</span><span>Showing the AI’s removed claims looks like a weakness. I think it’s what makes the rest believable.</span></li>
          <li><span>Depth over screen count</span><span>I chose one flow with every state over many happy-path screens. Formal wireframes and flow diagrams are still to do.</span></li>
        </ul>
        <p className="muted" style={{ marginTop: 24, fontSize: 'var(--fs-xs)' }}>ResolveAI, Northwind Retail and all people and data shown are fictional.</p>
      </Section>

      <CaseFooter slug="resolveai" />
    </>
  );
}
