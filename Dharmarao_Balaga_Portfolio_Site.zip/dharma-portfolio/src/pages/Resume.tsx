import { site } from '../data/site';
import { Icon } from '../components/Icon';
import { Link } from '../lib/router';
import { ContactButton } from '../components/ContactButton';
import { useDocumentTitle } from '../lib/useDocumentTitle';

// Content mirrors Dharmarao_Balaga_Principal_Product_Designer_Resume.pdf (the supplied, most recent resume).
const competencies: [string, string][] = [
  ['Product & Strategy', 'Product Thinking · UX Strategy · Product Discovery · Problem Framing · Data-informed Design · Design Consulting'],
  ['Research & UX', 'User Research · Usability Testing · Research Synthesis · User Journeys · Information Architecture · User Flows · Wireframing'],
  ['Interaction & UI', 'Interaction Design · Rapid Prototyping · High-fidelity UI · Mobile & Responsive Design · Visual Design · Motion'],
  ['Systems & Scale', 'Design Systems · Scalable Component Libraries · Design Tokens · Design Standards & Governance'],
  ['Leadership', 'Design Team Leadership · Mentoring · Stakeholder Management · Cross-functional Collaboration (Product, Engineering, Marketing)'],
  ['Domains', 'Mobile Gaming · SaaS & B2B · E-commerce · Enterprise Software · E-learning'],
];

const tools: [string, string][] = [
  ['Design & Prototyping', 'Figma · Figma AI / Figma Make · Google Stitch'],
  ['Generative AI for UX', 'ChatGPT · Claude · Google Gemini — discovery, research synthesis, ideation, UX writing, prototyping'],
  ['Generative Visual & Motion', 'Midjourney · Leonardo AI · Runway ML — visual exploration, concept art, motion studies'],
  ['AI Experience Design', 'Human-centered AI patterns · Human-in-the-loop workflows · AI-assisted design productivity'],
];

const jobs = [
  {
    role: 'Founder & Principal Product Designer',
    org: 'D’SARAS Design Studio, Hyderabad — AI-enabled design studio',
    when: 'Feb 2025 – Present',
    points: [
      ['End-to-end product design consulting:', 'lead engagements for startups and businesses from discovery and problem framing through UX strategy, information architecture, interaction design, prototyping and high-fidelity UI.'],
      ['AI-assisted design practice:', 'built a studio workflow that uses ChatGPT, Claude, Gemini, Figma Make and Google Stitch for research synthesis, ideation and rapid prototyping, significantly reducing design turnaround time.'],
      ['Design systems:', 'created scalable design systems and component libraries, including the studio’s own DSDS system with design tokens, wing-specific colour themes and responsive patterns.'],
      ['OnlyTWAM:', 'delivered complete UX/UI for a premium women’s essentials e-commerce mobile app — multi-screen UI and an interactive prototype built on a dedicated brand design system.'],
      ['D’SARAS digital presence:', 'designed and built the studio’s multi-section website (Design, Growth, Academy and Stories) as a responsive single-page application.'],
      ['DesignAcharya (emerging initiative):', 'designing a 6-month UX/UI and Product Design programme with AI-era positioning, aimed at mother-tongue-first (Telugu–English) design education.'],
    ],
  },
  {
    role: 'Head of Product Design',
    org: 'Openplay Technologies (Nazara Games), Hyderabad',
    when: 'Jan 2018 – Jan 2025',
    points: [
      ['Design leadership:', 'owned product design strategy and execution across multiple gaming and digital product ecosystems for 7 years; built, managed and mentored a multidisciplinary design team.'],
      ['Classic Rummy transformation:', 'led the redesign from a legacy Flash product to a modern native mobile experience — reimagining onboarding, navigation and gameplay flows with culturally relevant UI for Indian users, improving retention and engagement.'],
      ['Design systems & standards:', 'partnered with Product, Engineering, Marketing and Leadership to establish design standards and scalable design systems for consistent delivery across products.'],
      ['Data-informed decisions:', 'drove data-informed design decisions, using user research and product insights to prioritise improvements.'],
      ['AI adoption:', 'introduced AI-assisted research and design workflows that raised team productivity.'],
    ],
  },
  {
    role: 'Design Manager / Creative Head',
    org: 'Adeon Media Technologies, Hyderabad',
    when: 'Mar 2014 – Jan 2018',
    points: [
      ['UX & creative strategy:', 'led UX/UI and creative direction for enterprise and consumer web and mobile applications, including work for client brand Frodoe.'],
      ['Team leadership:', 'managed multidisciplinary design teams across concept, UX and visual design.'],
      ['Research-led delivery:', 'conducted user research and usability evaluations to deliver scalable, user-centred digital experiences.'],
    ],
  },
  {
    role: 'Earlier Career — Illustrator → Graphic Designer → Animator → Team Lead',
    org: 'Cordys Software · Esya Technologies · Helix Tech Solutions · The Boston Group · Polygon Studios · Globarena Technologies · Color Chips India',
    when: '2001 – 2014',
    points: [
      ['', 'Progressed from illustration to team leadership across software, e-learning, animation and visual-communication companies.'],
      ['', 'Built deep foundations in branding, e-learning content, character and animation design, and visual storytelling that now strengthen product, motion and interaction work.'],
    ],
  },
];

export function Resume() {
  useDocumentTitle('Resume — Dharmarao Balaga', 'Resume of Dharmarao Balaga: Senior / Principal Product Designer with nearly 20 years across product design, UX strategy, design leadership and AI-enabled innovation.');
  const r = site.documents.resume;
  return (
    <>
      <section className="doc-head">
        <div className="wrap">
          <p className="eyebrow eyebrow--accent">Resume</p>
          <h1 className="h-display">Experience, leadership, and product thinking.</h1>
          <p className="lede">
            A concise overview of my experience across product design, UX strategy, design leadership, and AI-enabled
            innovation.
          </p>
          <div className="doc-tools">
            <a className="btn btn--primary" href={r.href} download={r.filename}><Icon name="download" /> Download Resume (PDF)</a>
            <a className="btn btn--ghost" href={r.href} target="_blank" rel="noopener noreferrer"><Icon name="external" /> Open PDF</a>
            <button type="button" className="btn btn--ghost" onClick={() => window.print()}><Icon name="print" /> Print</button>
          </div>
        </div>
      </section>

      <div className="wrap doc-layout">
        <article className="paper resume" aria-label="Resume">
          <header className="paper__head">
            <p className="paper__name">Dharmarao Balaga</p>
            <p className="paper__role">Senior / Principal Product Designer · AI-Driven Product Design · UX Strategy</p>
            <p className="paper__contact">
              <span>{site.location}</span>
              <a href={site.phoneHref}>{site.phone}</a>
              <a href={`mailto:${site.email}`}>{site.email}</a>
              <a href={site.linkedin} target="_blank" rel="noopener noreferrer">{site.linkedinLabel}</a>
              <a href={site.behance} target="_blank" rel="noopener noreferrer">{site.behanceLabel}</a>
            </p>
          </header>

          <h2>Professional summary</h2>
          <p>
            Senior product design leader with nearly 20 years of experience across mobile, gaming, SaaS and enterprise
            products, including 7 years as Head of Product Design at Openplay Technologies (Nazara Games). Combines
            product thinking, user-centered research, UX strategy and interaction design with hands-on craft in design
            systems and high-fidelity UI — and a foundation in animation, visual communication and storytelling from an
            M.Des at IIT Bombay.
          </p>
          <p style={{ marginTop: 12 }}>
            Today, as Founder &amp; Principal Product Designer of D’SARAS Design Studio, applies generative AI
            strategically across discovery, research synthesis, ideation, rapid prototyping and visual exploration —
            shortening the path from problem to validated design while keeping human judgment, usability and business
            goals at the centre.
          </p>

          <h2>Core competencies</h2>
          {competencies.map(([k, v]) => (
            <dl className="rcomp" key={k}><dt>{k}</dt><dd>{v}</dd></dl>
          ))}

          <h2>AI &amp; design tools</h2>
          {tools.map(([k, v]) => (
            <dl className="rcomp" key={k}><dt>{k}</dt><dd>{v}</dd></dl>
          ))}

          <h2>Professional experience</h2>
          {jobs.map((j) => (
            <section className="job" key={j.role} aria-label={j.role}>
              <div className="job__top">
                <h3>{j.role}</h3>
                <span className="when">{j.when}</span>
              </div>
              <p className="org">{j.org}</p>
              <ul>
                {j.points.map(([b, t]) => (
                  <li key={t.slice(0, 30)}>{b && <b>{b} </b>}{t}</li>
                ))}
              </ul>
            </section>
          ))}

          <h2>Selected projects</h2>
          <div className="rproj">
            <div>
              <h3><Link to="/work/classic-rummy">Classic Rummy — Mobile Gaming</Link><small>Openplay Technologies · Shipped 2018 · discontinued 2025</small></h3>
              <p>Migrated a legacy Flash card game to a native mobile experience. Redesigned onboarding, navigation and core gameplay flows with culturally relevant UI for Indian players, improving retention and engagement.</p>
            </div>
            <div>
              <h3><Link to="/work/twam">OnlyTWAM — E-commerce Mobile App</Link><small>D’SARAS Design Studio</small></h3>
              <p>End-to-end UX/UI for a premium women’s essentials app: core shopping flows, a calm minimal visual language, a brand design system and an interactive prototype.</p>
            </div>
            <div>
              <h3><Link to="/work/resolveai">ResolveAI — AI Customer Support SaaS</Link><small>Self-initiated concept · Portfolio project</small></h3>
              <p>Concept for an enterprise B2B support platform where AI assists and human agents stay in control. Covers ticket management, agent workflows, analytics dashboards and AI quality monitoring, with explicit human-in-the-loop decisions and trade-offs documented in a full case study.</p>
            </div>
            <div>
              <h3>D’SARAS Design Studio — Digital Presence<small>Own studio</small></h3>
              <p>Brand identity, design system (DSDS) and a responsive multi-section website presenting the studio’s Design, Growth, Academy and Stories wings, with integrated portfolio and curriculum content.</p>
            </div>
          </div>

          <h2>Education</h2>
          <ul style={{ listStyle: 'none', display: 'grid', gap: 10 }}>
            <li><b style={{ color: 'var(--c-ink)' }}>Master of Design (M.Des)</b> — Design, Animation &amp; Film — Indian Institute of Technology Bombay (IIT Bombay)</li>
            <li><b style={{ color: 'var(--c-ink)' }}>Bachelor of Fine Arts (BFA)</b> — Applied Arts — JNAFAU, Hyderabad</li>
          </ul>

          <h2>Languages &amp; availability</h2>
          <p><b style={{ color: 'var(--c-ink)' }}>Languages:</b> English, Telugu, Hindi</p>
          <p><b style={{ color: 'var(--c-ink)' }}>Open to:</b> Senior / Principal Product Designer, AI Product Designer and Product Design Consultant roles — Hybrid, Onsite or Remote</p>

          <h2>Contact</h2>
          <p>
            <a href={site.phoneHref}>{site.phone}</a> · <a href={`mailto:${site.email}`}>{site.email}</a> · <a href={site.linkedin} target="_blank" rel="noopener noreferrer">LinkedIn</a> · <a href={site.behance} target="_blank" rel="noopener noreferrer">Behance</a> · {site.location}
          </p>
        </article>

        <aside className="doc-aside" aria-label="Resume actions">
          <div className="card">
            <span className="k">Download</span>
            <p>{r.filename}<br /><span className="muted">{r.size}</span></p>
            <a className="btn btn--dark" style={{ width: '100%' }} href={r.href} download={r.filename}><Icon name="download" /> Download PDF</a>
          </div>
          <div className="card">
            <span className="k">Also available</span>
            <div style={{ display: 'grid', gap: 10 }}>
              <Link to="/cover-letter" className="btn btn--ghost">Read Cover Letter</Link>
              <ContactButton align="right" />
            </div>
          </div>
        </aside>
      </div>
    </>
  );
}
