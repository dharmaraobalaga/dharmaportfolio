import { CaseHero, CaseFooter, Decision, HMW, Notice, Persona, Prototype, Section, SubNav, Swatches } from '../components/CaseStudy';
import { Figure, ProjectGallery } from '../components/ProjectGallery';
import { asset } from '../lib/asset';
import { site } from '../data/site';
import { useDocumentTitle } from '../lib/useDocumentTitle';

const img = (n: string) => asset(`images/rummy/${n}.jpg`);
const PROTO = 'https://www.figma.com/proto/7ATYEy8vBkBD2cpt0nprZR/Classic-Rummy-Prototype';
// Behance: full design set, promo videos and animations. Replace with the Classic Rummy project URL when available.
const BEHANCE = site.behance;

const nav = [
  { id: 'overview', label: 'Overview' },
  { id: 'users', label: 'Users' },
  { id: 'role', label: 'Role' },
  { id: 'research', label: 'Research' },
  { id: 'ia', label: 'IA & exploration' },
  { id: 'decisions', label: 'Decisions' },
  { id: 'final', label: 'Final UI' },
  { id: 'outcomes', label: 'Outcomes' },
  { id: 'lens', label: 'Looking back' },
];

const survey: [string, number][] = [
  ['Prefer playing on a smartphone', 85],
  ['Interactive tutorials help learn rules', 85],
  ['Prefer a clean, minimal design', 80],
  ['Tournaments & leaderboards are essential', 75],
  ['Feel secure making transactions', 75],
  ['Actively use chat or multiplayer', 65],
  ['Use daily challenges or practice often', 60],
  ['Private tables with friends are a priority', 55],
];

const portrait = [
  { src: img('splash'), alt: 'Splash screen with four trust badges: Faster Withdrawals, Secure Payments, Real Players, RNG Certified', label: 'Splash · trust signals', w: 398, h: 885 },
  { src: img('register'), alt: 'Register screen with welcome bonus banner and a single mobile number field', label: 'Register · one field', w: 398, h: 885 },
  { src: img('login'), alt: 'Login screen with referral bonus banner and OTP or password options', label: 'Login · OTP or password', w: 398, h: 885 },
  { src: img('add-cash'), alt: 'Add cash screen with preset amounts, promo codes and deposit summary', label: 'Add cash · preset amounts', w: 402, h: 984 },
  { src: img('withdraw'), alt: 'Withdraw funds screen with amount and withdrawal method', label: 'Withdraw · clear limits', w: 398, h: 984 },
].map((x) => ({ ...x, caption: x.label }));

const landscape = [
  { src: img('tournaments'), alt: 'Tournament categories lobby with illustrated category tiles', label: 'Tournaments by category', w: 889, h: 398 },
  { src: img('result'), alt: 'Game result screen with winner, mystery reward and Play Again button', label: 'Result · Play again in one tap', w: 892, h: 402 },
  { src: img('challenge'), alt: 'Seven-day challenge progress panel', label: '7-day challenge', w: 889, h: 402 },
  { src: img('leaderboard'), alt: 'Live leaderboard with ranks and prizes', label: 'Live leaderboard', w: 889, h: 392 },
  { src: img('drawer'), alt: 'Side navigation menu with account, KYC, withdrawals and promotions', label: 'Navigation drawer', w: 889, h: 401 },
  { src: img('support'), alt: 'Support screen with call, email and ticket options', label: 'Support · human contact visible', w: 892, h: 402 },
].map((x) => ({ ...x, caption: x.label }));

export function ClassicRummy() {
  useDocumentTitle(
    'Classic Rummy case study — Dharmarao Balaga',
    'How Dharmarao Balaga led the redesign of Classic Rummy from a legacy Flash game into native Android and iOS apps for Openplay Technologies (Nazara Group).',
  );
  return (
    <>
      <CaseHero
        slug="classic-rummy"
        eyebrow="Case study 01"
        title="Rebuilding Classic Rummy for a post-Flash, mobile-first India"
        lede="When Chrome began phasing out Flash, a popular web card game lost its home. I led the end-to-end redesign into native Android, iOS and web experiences, rethinking onboarding, navigation and gameplay for first-time players and tournament regulars alike."
        tags={[{ label: 'Shipped 2018 · Discontinued 2025', kind: 'status' }, { label: 'Mobile Gaming · Product Transformation' }]}
        prototype={{ href: PROTO, label: 'View Figma prototype' }}
        extraLink={{ href: BEHANCE, label: 'Designs & promo videos on Behance' }}
        meta={[
          { k: 'Company', v: 'Openplay Technologies (Nazara Group)' },
          { k: 'My role', v: 'Product design lead: end-to-end UX/UI ownership' },
          { k: 'Timeline', v: 'Feb – May 2018 · ~12 weeks' },
          { k: 'Platforms', v: 'Android · iOS · Web' },
          { k: 'Status', v: 'Shipped 2018 · discontinued after the 2025 ban' },
        ]}
        notice={
          <Notice>
            <b>Reading this in 2026.</b> This case study documents a real-money gaming product as it was designed in 2018.
            India’s Promotion and Regulation of Online Gaming Act, 2025 has since prohibited online money games, so the
            wallet, KYC and cash-game flows below reflect the product’s original context. Like other real-money gaming
            platforms in India, Classic Rummy stopped operating after the ban; the app and website are no longer live, so the
            Figma prototype and the screens below are the best record of the design. The final section, “Looking back from
            2026”, separates today’s recommendations from what shipped.
          </Notice>
        }
        media={
          <div style={{ background: '#0d0f0e', display: 'flex', justifyContent: 'center', padding: 'clamp(20px, 4vw, 56px)' }}>
            <img src={img('hero')} alt="Classic Rummy lobby and gameplay table shown on two tilted landscape phones" width={1084} height={1010} style={{ width: 'min(620px, 100%)', borderRadius: 12, boxShadow: '0 30px 60px rgb(0 0 0 / 50%)' }} fetchPriority="high" />
          </div>
        }
      />
      <SubNav items={nav} />

      <Section
        id="overview" n="01" label="Overview & problem"
        title="A traditional game, a platform that stopped working overnight"
        intro={
          <>
            <p>
              Classic Rummy is Openplay’s digital take on Indian Rummy: a skill-based card game where players build valid
              sets and sequences under time pressure. It offered Points, Pool and Deals formats to an audience ranging from
              curious beginners to daily tournament players.
            </p>
            <p>
              In 2018, Google Chrome began phasing out Flash. The entire Flash-based platform was heading toward
              obsolescence, putting accessibility, retention and device compatibility at risk at once. We needed a native
              experience that felt modern, ran smoothly on everyday Android phones, and earned enough trust for people to play.
            </p>
          </>
        }
      >
        <div className="grid-3">
          <div className="card"><span className="k">Objective 1</span><p>Make the game learnable for new players without slowing down experts.</p></div>
          <div className="card"><span className="k">Objective 2</span><p>Simplify the core paths: sign-up, finding a table, playing, and managing money.</p></div>
          <div className="card"><span className="k">Objective 3</span><p>Support retention with tutorials, challenges, leaderboards and tournaments.</p></div>
        </div>
        <HMW>…design an intuitive, engaging rummy app that works for both novice and expert players, and keeps gameplay seamless across devices?</HMW>
      </Section>

      <Section
        id="users" n="02" label="Target users"
        title="Two players, one lobby"
        intro={<p>Research surfaced two dominant mindsets. The tension between them, relaxed learning versus fast, high-stakes competition, shaped almost every layout decision.</p>}
      >
        <div className="grid-2">
          <Persona
            tag="Persona · Casual player" name="Vineet, 28" sub="Software engineer · Pune · moderate tech comfort"
            quote="Will I be able to play this without prior experience? Is it safe to put my money here?"
            rows={[
              ['Needs', 'Clear rules, a pressure-free practice space, an obvious path from learning to playing.'],
              ['Pain points', 'Confusing navigation, intimidating competition, committing money up front.'],
              ['Design opportunity', 'Guided onboarding, a separate practice mode, clearly labelled game types.'],
            ]}
          />
          <Persona
            tag="Persona · Competitive player" name="Rajesh, 55" sub="Regular tournament player · high engagement"
            quote="I need smooth gameplay with no interruptions. Are my winnings secure and processed quickly?"
            rows={[
              ['Needs', 'Fast access to tournaments and cash tables, visible rankings, transparent prizes.'],
              ['Pain points', 'Lag and crashes mid-game, unclear rules and prize distribution.'],
              ['Design opportunity', 'One-tap paths to competitive modes, live leaderboards, readable large-type UI.'],
            ]}
          />
        </div>
      </Section>

      <Section
        id="role" n="03" label="My role"
        title="I owned the design end to end, from interviews to dev handoff"
        intro={<p>I worked with product, engineering and QA at Openplay. The scope covered research, information architecture, interaction and visual design, the UI kit, and post-launch iteration.</p>}
      >
        <div className="grid-3">
          {[
            ['Research', 'Interviews, surveys and a five-app competitive audit.'],
            ['UX & UI design', 'IA, flows, wireframes, prototypes and final screens.'],
            ['Design documentation', 'Colour, type and component guidelines for the team.'],
            ['Asset delivery', 'Optimised UI assets and handoff for development.'],
            ['Usability testing', 'Task-based tests and feedback sessions after MVP.'],
            ['Iteration', 'Redesigning from findings and live feedback.'],
          ].map(([k, v]) => <div className="card" key={k}><h3>{k}</h3><p>{v}</p></div>)}
        </div>
        <ul className="list-rows" style={{ marginTop: 28 }} aria-label="Design timeline 2018">
          <li><span>Feb 9 – May 2, 2018</span><span>Empathise &amp; define → Ideate &amp; prototype → Test &amp; implement → Finalise &amp; launch</span></li>
        </ul>
      </Section>

      <Section
        id="research" n="04" label="Research & insights"
        title="Players didn’t want more features. They wanted less friction and more trust."
        intro={<p>I combined interviews with existing Flash players, a qualitative and a quantitative survey, and an audit of five leading Indian rummy apps (Junglee Rummy, RummyCircle, Adda52 Rummy, A23 and Rummy Culture).</p>}
      >
        <div className="grid-2">
          {[
            ['The old platform felt slow', 'Interviewees described Flash Classic Rummy as dated and sluggish. Speed was the baseline expectation.'],
            ['Rules are the first barrier', 'New players struggled to understand game variants and scoring before their first hand.'],
            ['Trust must be visible', 'Players wanted reassurance about payments, withdrawals and fair play: on screen, not in fine print.'],
            ['Competitors left a gap', 'Established apps had dated UI or slow payouts; newer ones were sleek but thin on game variety.'],
          ].map(([t, b], i) => (
            <div className="card" key={t}><span className="num">0{i + 1}</span><h3>{t}</h3><p>{b}</p></div>
          ))}
        </div>

        <div className="grid-2" style={{ marginTop: 40, alignItems: 'start', gap: 32 }}>
          <div>
            <h3 className="h-5" style={{ marginBottom: 6 }}>Quantitative survey</h3>
            <p className="muted" style={{ fontSize: 'var(--fs-sm)', marginBottom: 18 }}>Existing players, 2018 · % answering “yes”</p>
            <ul className="bars">
              {survey.map(([k, v]) => (
                <li key={k}><span>{k}</span><b>{v}%</b><span className="bar" aria-hidden="true"><i style={{ width: `${v}%` }} /></span></li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="h-5" style={{ marginBottom: 18 }}>What this told us to prioritise</h3>
            <ul className="list-rows">
              <li><span>Mobile first, landscape for play</span><span>85% preferred phones; a card hand needs width.</span></li>
              <li><span>Teach inside the product</span><span>85% valued interactive tutorials over help pages.</span></li>
              <li><span>Competition is core</span><span>Tournaments and leaderboards earn a top-level entry, not an add-on.</span></li>
              <li><span>Social is secondary</span><span>Valued but not universal: present, never in the way.</span></li>
            </ul>
          </div>
        </div>

        <h3 className="h-5" style={{ margin: '44px 0 16px' }}>Casual player journey</h3>
        <div className="journey">
          <div><h4>Awareness</h4><p className="risk">Worries about complexity and real-money safety.</p><p className="resp">Lead with trust signals.</p></div>
          <div><h4>Onboarding</h4><p className="risk">Confused by variants.</p><p className="resp">Mobile + OTP sign-up; How to Play always in reach.</p></div>
          <div><h4>Engagement</h4><p className="risk">Overwhelmed by high stakes.</p><p className="resp">Practice games as a first-class door.</p></div>
          <div><h4>Loyalty</h4><p className="risk">Intimidated by experts.</p><p className="resp">Challenges and progress to celebrate milestones.</p></div>
        </div>
      </Section>

      <Section
        id="ia" n="05" label="IA & exploration"
        title="Everything hangs off one lobby"
        intro={<p>I organised the app around a single Home Lobby with four branches. Playing is always one tap away; money, progress and account settings stay reachable without crowding the table.</p>}
        wide={
          <>
            <div className="ia">
              <div className="ia__root">Splash <i>→</i> Register / Login (mobile + OTP) <i>→</i> Home Lobby</div>
              <div className="ia__cols">
                <div className="ia__col"><h4>Play</h4><ul><li>Practice games</li><li>Cash games</li><li>Tournaments</li><li className="sub">↳ Points · Pools · Deals</li><li className="sub">↳ Table → Result → Play again</li></ul></div>
                <div className="ia__col"><h4>Wallet</h4><ul><li>Balance &amp; bonus</li><li>Add cash</li><li>Withdraw</li><li>KYC (digital / manual)</li><li>Transaction reports</li></ul></div>
                <div className="ia__col"><h4>Progress</h4><ul><li>Challenges</li><li>Leaderboards</li><li>Promotions</li><li>Refer a friend</li><li>Rewards</li></ul></div>
                <div className="ia__col"><h4>Account</h4><ul><li>Profile &amp; location</li><li>Settings (sound, themes)</li><li>How to play &amp; FAQs</li><li>Support</li><li>Responsible gaming</li></ul></div>
              </div>
            </div>
            <div style={{ display: 'grid', marginTop: 40, gap: 32 }}>
              <Figure
                src={img('lofi-wireframes')} w={1600} h={802} dark
                alt="Grey low-fidelity wireframes exploring lobby layouts, a dial-style point-value selector and table lists"
                caption={<><b>Low-fidelity exploration.</b> Early concepts used a dial to pick player count and point value before joining. It looked playful but hid the actual tables, which led to Decision 3.</>}
              />
              <Figure
                src={img('hifi-wireframes')} w={1800} h={304} dark
                alt="Greyscale high-fidelity wireframes of splash, register, login, withdraw, add cash, lobby and table list screens"
                caption={<><b>High-fidelity wireframes.</b> Portrait for accounts and money, landscape for play.</>}
              />
            </div>
          </>
        }
      />

      <Section id="decisions" full n="06" label="Key decisions" title="Five calls that shaped the product">
        <div>
          <Decision
            n={1} title="Three doors, not one menu: Practice · Cash · Tournaments"
            tradeoff="large illustrated tiles use space a denser list would give to more options. We accepted fewer choices on screen for faster recognition."
            media={<Figure src={img('lobby')} w={889} h={395} dark alt="Home lobby with Practice Games, Cash Games and Tournaments tiles" />}
          >
            <p>Vineet needs a safe place to learn; Rajesh wants competition immediately. Giving each mindset its own door serves both from the same lobby.</p>
          </Decision>
          <Decision
            n={2} title="Landscape for the table, portrait for everything around it"
            tradeoff="an orientation switch between flows. We kept it to clear boundaries (entering or leaving a money flow) so it never happens mid-task."
            media={<Figure src={img('table')} w={892} h={395} dark alt="Landscape 101 Pool table with five players, grouped card hand, Sort, Drop and Show actions" />}
          >
            <p>A 13-card hand grouped into sets and sequences needs horizontal space to stay readable and draggable. Forms such as sign-up, deposits and withdrawals read better in portrait.</p>
          </Decision>
          <Decision
            n={3} title="Replace the dial picker with a filterable table list"
            tradeoff="a data table is less inviting for beginners, so it lives behind the Cash door; Practice stays visual and simple."
            media={<Figure src={img('table-list')} w={889} h={418} dark alt="Pools table list with filters for players, game type and entry level, and Play Now buttons" />}
          >
            <p>Regulars choose tables by players, entry fee and status. Showing the real tables, with quick filters for format, seats and stakes, removed a guess-then-wait step.</p>
          </Decision>
          <Decision n={4} title="Make trust a first-screen feature" tradeoff="a busier header. I grouped balances into one pill with a single high-contrast action to keep it scannable.">
            <p>The splash screen leads with Faster Withdrawals, Secure Payments, Real Players and RNG Certified; the lobby keeps cash, bonus and Add Cash permanently visible.</p>
          </Decision>
          <Decision n={5} title="Retention through progress, not pop-ups" tradeoff="post-MVP testing showed challenges were easy to miss, so visibility on the home screen became a follow-up.">
            <p>A 7-day challenge, live leaderboards and tournament timers on the table give regulars a reason to return, and give beginners small, achievable goals.</p>
          </Decision>
        </div>
      </Section>

      <Section
        id="final" n="07" label="Final UI & design system"
        title="Familiar felt-table green, modern clarity"
        intro={<p>The visual language borrows the comfort of a real card table, deep green with gold highlights, while using flat surfaces, large type and bold, single-purpose buttons for readability on budget Android phones.</p>}
        wide={
          <>
            <div className="gallery-group">
              <h3>Onboarding &amp; money · portrait</h3>
              <ProjectGallery layout="phones" items={portrait} dark />
            </div>
            <div className="gallery-group">
              <h3>Lobby, play &amp; progress · landscape</h3>
              <ProjectGallery layout="land" items={landscape} dark />
            </div>
            <Prototype href={PROTO} title="Clickable prototype" body="The 2018 Figma prototype covers onboarding, the lobby, table selection and money flows." cta="Open in Figma" />
            <Prototype href={BEHANCE} title="Full design set & promo videos" body="The complete Classic Rummy design set, promotional videos and motion work are on Behance, the best way to see the shipped product now that the app is no longer live." cta="View on Behance" />

            <div className="grid-2" style={{ marginTop: 56, gap: 32, alignItems: 'start' }}>
              <div>
                <h3 className="h-5" style={{ marginBottom: 16 }}>UI kit · colour</h3>
                <Swatches colors={[{ hex: '#4ECC11' }, { hex: '#4AAC1B' }, { hex: '#355F22' }, { hex: '#FFD232' }, { hex: '#303030' }]} />
                <p className="muted" style={{ marginTop: 14, fontSize: 'var(--fs-sm)' }}>Green for primary actions and the table, gold for money and rewards, neutrals for chrome. Semantic: success #12D80E, error #F82A2A.</p>
              </div>
              <div>
                <h3 className="h-5" style={{ marginBottom: 16 }}>UI kit · type &amp; accessibility</h3>
                <ul className="list-rows">
                  <li><span>Montserrat Bold</span><span>Titles · 20/24 · 16/20 · 12/16</span></li>
                  <li><span>Roboto</span><span>Body · Medium 14/18 · SemiBold 12/16 · Regular 10–16</span></li>
                  <li><span>Accessibility</span><span>Contrast checked against WCAG 2.1, scalable type, labelled icons and screen-reader-friendly structure.</span></li>
                </ul>
              </div>
            </div>
          </>
        }
      />

      <Section
        id="outcomes" n="08" label="Outcomes & lessons"
        title="What shipped, what we tested, what we learned"
        intro={<p>The redesigned app shipped on Android and iOS in 2018. After the MVP, a usability study with new and existing players used task-based tests, interviews and task-completion and time-on-task measures.</p>}
      >
        <div className="grid-3">
          <div className="card"><span className="k">Worked</span><p>Minimal design and smooth navigation were well received.</p></div>
          <div className="card"><span className="k">Didn’t yet</span><p>Scoring was unclear; rules needed clearer onboarding; challenges and rewards were too easy to miss.</p></div>
          <div className="card"><span className="k">Next</span><p>Refined tutorials, in-context scoring help, and challenges promoted on the home screen.</p></div>
        </div>
        <h3 className="h-5" style={{ margin: '40px 0 16px' }}>Lessons</h3>
        <ul className="list-rows">
          <li><span>Research earns its keep</span><span>The two-persona split came straight from interviews and decided the lobby’s structure.</span></li>
          <li><span>Design integrity is a team sport</span><span>Working with developers through handoff kept the table’s interactions faithful on low-end devices.</span></li>
          <li><span>Ship, then listen</span><span>The usability study found gaps we couldn’t have predicted. Onboarding is never finished.</span></li>
        </ul>
      </Section>

      <section id="lens" className="cs-sec" aria-labelledby="lens-title">
        <div className="wrap">
          <div className="lens" style={{ marginTop: 0 }}>
            <span className="eyebrow eyebrow--accent">Looking back from 2026 · current recommendations, not shipped work</span>
            <h2 id="lens-title" className="h-3">How I’d approach it today</h2>
            <p className="prose">With India’s 2025 ban on online money games, the business model this design served no longer applies. These are proposals and hypotheses showing how the same research would steer a redesign now.</p>
            <div className="grid-2" style={{ marginTop: 28 }}>
              <div className="card"><span className="k">Model</span><h3>The Practice door becomes the product</h3><p>A free-to-play social skill game: friends’ tables, clubs and seasonal tournaments with non-cash rewards. The wallet header becomes a progress and streak header.</p></div>
              <div className="card"><span className="k">Accessibility</span><h3>Four-colour suits and larger hit areas</h3><p>Red/black suits rely on hue; a four-colour deck option plus shape cues and 44px+ targets would serve colour-blind and older players like Rajesh.</p></div>
              <div className="card"><span className="k">Learning</span><h3>An opt-in AI table coach</h3><p>Contextual hints that explain a valid sequence or a better discard, solving the rules barrier from research in the moment. To validate: hint usage vs. first-week retention.</p></div>
              <div className="card"><span className="k">Workflow</span><h3>AI-assisted research, human-made decisions</h3><p>I’d use AI to cluster open-ended survey answers and draft affinity groups, then verify each theme against raw quotes before it informs a design decision.</p></div>
            </div>
          </div>
          <p className="muted" style={{ marginTop: 20, fontSize: 'var(--fs-xs)' }}>Classic Rummy is a product of Openplay Technologies (Nazara Group).</p>
        </div>
      </section>

      <CaseFooter slug="classic-rummy" />
    </>
  );
}
