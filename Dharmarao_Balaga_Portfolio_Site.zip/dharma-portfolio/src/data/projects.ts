import { asset } from '../lib/asset';
import { site } from './site';

export type ProjectSlug = 'classic-rummy' | 'resolveai' | 'twam';

export interface ProjectSummary {
  slug: ProjectSlug;
  route: string;
  number: string;
  title: string;
  tagline: string;
  description: string;
  category: string;
  context: string;
  role: string;
  status: string;
  statusKind: 'shipped' | 'concept' | 'prototype';
  /** Optional extra row on the card, e.g. a Behance showcase link. */
  showcase?: { label: string; href: string; key?: string };
  cover: string[];
  coverAlt: string[];
}

export const projects: ProjectSummary[] = [
  {
    slug: 'classic-rummy',
    route: '/work/classic-rummy',
    number: '01',
    title: 'Classic Rummy',
    tagline: 'Rebuilding Classic Rummy for a post-Flash, mobile-first India.',
    description:
      'When Chrome began phasing out Flash, a popular web card game lost its platform. I led the end-to-end redesign into native Android and iOS apps, rethinking onboarding, navigation and gameplay so first-time players and tournament regulars could share one lobby.',
    category: 'Mobile Gaming · Product Transformation',
    context: 'Openplay Technologies (Nazara Group)',
    role: 'Product design leadership, end-to-end UX/UI ownership',
    status: 'Shipped 2018 · discontinued after India’s 2025 ban on online money games',
    statusKind: 'shipped',
    showcase: { label: 'Designs & promo videos on Behance', href: site.behance },
    cover: [asset('images/rummy/hero.jpg')],
    coverAlt: ['Classic Rummy lobby and gameplay table shown on two tilted landscape phones'],
  },
  {
    slug: 'resolveai',
    route: '/work/resolveai',
    number: '02',
    title: 'ResolveAI',
    tagline: 'An AI copilot that agents can check, correct, and overrule.',
    description:
      'A customer-support workspace where AI summarises tickets, cites its sources, drafts replies and suggests next steps, but never sends or acts on its own. Designed around the moments AI is most likely to fail: thin data, invented facts and outages.',
    category: 'B2B SaaS · AI Product Design',
    context: 'Self-initiated portfolio concept',
    role: 'Sole product designer, from problem framing to prototype',
    status: 'Concept · not a shipped product',
    statusKind: 'concept',
    cover: [asset('images/resolveai/inbox.jpg')],
    coverAlt: ['ResolveAI inbox with ticket list, customer conversation and the AI Copilot panel showing cited sources'],
  },
  {
    slug: 'twam',
    route: '/work/twam',
    number: '03',
    title: 'TWAM',
    tagline: 'Shopping for intimate essentials, designed around privacy and fit.',
    description:
      'A mobile shopping app for OnlyTWAM, a premium Indian essentials brand. Guest browsing, fit help that starts from the size she already wears, and discreet packaging chosen right where she pays.',
    category: 'Mobile Commerce · E-commerce UX',
    context: 'OnlyTWAM · D’SARAS Design Studio',
    role: 'End-to-end product design, UX strategy, UI and prototyping',
    status: 'Shipped · live on Google Play since 20 Jun 2026',
    statusKind: 'shipped',
    showcase: { key: 'Get the app', label: 'Download on Google Play', href: 'https://play.google.com/store/apps/details?id=in.twam.app&hl=en_IN' },
    cover: [asset('images/twam/onboarding-2.jpg'), asset('images/twam/home.jpg'), asset('images/twam/fit-result.jpg')],
    coverAlt: [
      'TWAM onboarding screen: Your private space to shop',
      'TWAM home screen with search, New Season banner and category grid',
      'TWAM fit finder result: Your perfect size M',
    ],
  },
];

export const projectBySlug = (slug: ProjectSlug) => projects.find((p) => p.slug === slug)!;
