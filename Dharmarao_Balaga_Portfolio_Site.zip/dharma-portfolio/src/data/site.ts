import { asset } from '../lib/asset';

/**
 * Single source of truth for contact details and downloadable documents.
 * Every value here is verified against Dharma's supplied resume and brief.
 */
export const site = {
  name: 'Dharmarao Balaga',
  shortName: 'Dharma Rao',
  location: 'Hyderabad, India',
  email: 'dharmaraobalaga@gmail.com',
  linkedin: 'https://linkedin.com/in/dharmarao-balaga-7a67937',
  linkedinLabel: 'linkedin.com/in/dharmarao-balaga-7a67937',
  behance: 'https://behance.net/dharmaportfolio',
  behanceLabel: 'behance.net/dharmaportfolio',
  descriptor: 'Senior / Principal Product Designer · UX Strategy · AI-Driven Product Innovation',
  availability: 'Open to Senior / Principal Product Design Opportunities',
  portrait: asset('images/dharma-portrait.jpg'),
  documents: {
    resume: {
      href: asset('documents/Dharmarao_Balaga_Principal_Product_Designer_Resume.pdf'),
      filename: 'Dharmarao_Balaga_Principal_Product_Designer_Resume.pdf',
      size: 'PDF · 2 pages',
    },
    coverLetter: {
      href: asset('documents/Dharmarao_Balaga_Cover_Letter.pdf'),
      filename: 'Dharmarao_Balaga_Cover_Letter.pdf',
      size: 'PDF · 1 page',
    },
  },
} as const;
