import { site } from '../data/site';
import { Icon } from './Icon';

export function ContactSection() {
  return (
    <section id="contact" className="section" aria-labelledby="contact-title">
      <div className="wrap contact__grid">
        <div className="reveal">
          <p className="eyebrow eyebrow--accent">Contact</p>
          <h2 id="contact-title" className="h-2">Let’s build something meaningful.</h2>
          <p className="lede">
            I’m open to conversations about product design leadership, principal designer roles, AI-driven product
            experiences, and selected consulting opportunities.
          </p>
          <div className="btn-row" style={{ marginTop: 28 }}>
            <a className="btn btn--primary" href={`mailto:${site.email}`}><Icon name="mail" /> Email me</a>
            <a className="btn btn--ghost" href={site.documents.resume.href} download={site.documents.resume.filename}>
              <Icon name="download" /> Download Resume
            </a>
          </div>
        </div>
        <ul className="contact-list reveal" aria-label="Contact details">
          <li>
            <a href={`mailto:${site.email}`}>
              <span className="k">Email</span><span className="v">{site.email}</span><Icon name="arrowUpRight" />
            </a>
          </li>
          <li>
            <a href={site.linkedin} target="_blank" rel="noopener noreferrer">
              <span className="k">LinkedIn</span><span className="v">{site.linkedinLabel}</span><Icon name="arrowUpRight" />
              <span className="sr-only">(opens in a new tab)</span>
            </a>
          </li>
          <li>
            <a href={site.behance} target="_blank" rel="noopener noreferrer">
              <span className="k">Behance</span><span className="v">{site.behanceLabel}</span><Icon name="arrowUpRight" />
              <span className="sr-only">(opens in a new tab)</span>
            </a>
          </li>
          <li>
            <div className="static"><span className="k">Location</span><span className="v">{site.location}</span><span /></div>
          </li>
        </ul>
      </div>
    </section>
  );
}
