import { useLightbox, ZoomImage, type LightboxItem } from './Lightbox';

interface GalleryItem extends LightboxItem {
  label: string;
  w: number;
  h: number;
}

interface Props {
  items: GalleryItem[];
  layout: 'phones' | 'land' | 'wide';
  dark?: boolean;
}

/** Responsive screenshot grid. Every image opens in a shared lightbox for the group. */
export function ProjectGallery({ items, layout, dark }: Props) {
  const { openAt, node } = useLightbox(items);
  return (
    <>
      <ul className={`gallery gallery--${layout}`} style={{ listStyle: 'none' }}>
        {items.map((it, i) => (
          <li key={it.src}>
            <figure className="figure">
              <div className={`frame${dark ? ' frame--dark' : ''}`}>
                <ZoomImage src={it.src} alt={it.alt} width={it.w} height={it.h} onOpen={() => openAt(i)} />
              </div>
              <figcaption>{it.label}</figcaption>
            </figure>
          </li>
        ))}
      </ul>
      {node}
    </>
  );
}

/** A single zoomable figure with caption. */
export function Figure({ src, alt, caption, w, h, dark, tall, className }: { src: string; alt: string; caption?: React.ReactNode; w: number; h: number; dark?: boolean; tall?: boolean; className?: string }) {
  const { openAt, node } = useLightbox([{ src, alt, caption: typeof caption === 'string' ? caption : alt, tall }]);
  return (
    <figure className={`figure ${className ?? ''}`}>
      <div className={`frame${dark ? ' frame--dark' : ''}`}>
        <ZoomImage src={src} alt={alt} width={w} height={h} onOpen={() => openAt(0)} />
      </div>
      {caption && <figcaption>{caption}</figcaption>}
      {node}
    </figure>
  );
}
