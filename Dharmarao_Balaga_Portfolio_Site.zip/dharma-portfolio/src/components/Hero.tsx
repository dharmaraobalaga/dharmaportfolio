import { Link } from '../lib/router';
import { site } from '../data/site';
import { Icon } from './Icon';

export function Hero() {
  return (
    <section className="hero" aria-labelledby="hero-title">
      <div className="wrap">
        <div className="hero__grid">
          <div>
            <div className="hero__status">
              <span className="pill"><span className="pill__dot" aria-hidden="true" />{site.availability}</span>
              <span className="loc"><Icon name="pin" />{site.location}</span>
            </div>
            <p className="hero__descriptor">{site.descriptor}</p>
            <h1 id="hero-title" className="h-display hero__title">
              Designing thoughtful digital products <span className="soft">for people and business.</span>
            </h1>
            <div className="hero__intro">
              <p>
                I’m a product design leader with nearly 20 years of experience across mobile, gaming, SaaS, e-commerce,
                and enterprise products. I combine user-centred design, product strategy, systems thinking, and visual
                storytelling to turn complex problems into intuitive digital experiences.
              </p>
              <p>
                Today, I explore how AI can accelerate product discovery, prototyping, and design execution while keeping
                human judgement, usability, and trust at the centre.
              </p>
            </div>
            <div className="btn-row hero__actions">
              <Link to="/work" className="btn btn--primary">
                Explore Selected Work <Icon name="arrowRight" className="arrow" />
              </Link>
              <a className="btn btn--ghost" href={site.documents.resume.href} download={site.documents.resume.filename}>
                <Icon name="download" /> Download Resume
              </a>
            </div>
          </div>
          <figure className="portrait">
            <div className="portrait__frame">
              <img
                src={site.portrait}
                alt="Portrait of Dharmarao Balaga smiling, in a dark suit and tie, black and white"
                width={960}
                height={960}
                fetchPriority="high"
              />
            </div>
            <figcaption>
              <span><b>Dharmarao Balaga</b> · Product Designer</span>
              <span>Hyderabad, India</span>
            </figcaption>
          </figure>
        </div>

        <dl className="facts">
          <div className="fact">
            <dt className="fact__k">Experience</dt>
            <dd className="fact__v">Nearly 20 years<span>Design, animation and product</span></dd>
          </div>
          <div className="fact">
            <dt className="fact__k">Now</dt>
            <dd className="fact__v">Founder &amp; Principal Product Designer<span>D’SARAS Design Studio · since Feb 2025</span></dd>
          </div>
          <div className="fact">
            <dt className="fact__k">Previously</dt>
            <dd className="fact__v">Head of Product Design<span>Openplay Technologies · 2018–2025</span></dd>
          </div>
          <div className="fact">
            <dt className="fact__k">Education</dt>
            <dd className="fact__v">M.Des, IIT Bombay<span>BFA Applied Arts, JNAFAU</span></dd>
          </div>
        </dl>
      </div>
    </section>
  );
}
