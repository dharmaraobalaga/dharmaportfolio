import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Icon } from './Icon';

export interface LightboxItem {
  src: string;
  alt: string;
  caption?: string;
  /** Tall images (long screens) scroll inside the viewer instead of shrinking. */
  tall?: boolean;
}

interface LightboxProps {
  items: LightboxItem[];
  index: number;
  onClose: () => void;
  onIndex: (i: number) => void;
}

export function Lightbox({ items, index, onClose, onIndex }: LightboxProps) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const item = items[index];
  const many = items.length > 1;
  const prev = useCallback(() => onIndex((index - 1 + items.length) % items.length), [index, items.length, onIndex]);
  const next = useCallback(() => onIndex((index + 1) % items.length), [index, items.length, onIndex]);

  useEffect(() => {
    const opener = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    closeRef.current?.focus();
    return () => {
      document.body.style.overflow = overflow;
      opener?.focus?.();
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === 'ArrowLeft' && many) prev();
      else if (e.key === 'ArrowRight' && many) next();
      else if (e.key === 'Tab' && ref.current) {
        const f = ref.current.querySelectorAll<HTMLElement>('button');
        if (!f.length) return;
        const first = f[0];
        const last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [many, next, prev, onClose]);

  return createPortal(
    <div
      ref={ref}
      className="lightbox"
      role="dialog"
      aria-modal="true"
      aria-label={item.caption ? `Image viewer: ${item.caption}` : 'Image viewer'}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="lightbox__bar">
        <span aria-live="polite">{many ? `${index + 1} of ${items.length}` : ''}</span>
        <button ref={closeRef} type="button" className="icon-btn" onClick={onClose} aria-label="Close image viewer">
          <Icon name="close" />
        </button>
      </div>
      <div className={`lightbox__stage${item.tall ? ' is-tall' : ''}`} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
        <img src={item.src} alt={item.alt} />
      </div>
      <div className="lightbox__foot">
        {many ? (
          <button type="button" className="icon-btn" onClick={prev} aria-label="Previous image"><Icon name="arrowLeft" /></button>
        ) : <span />}
        <p className="lightbox__cap">{item.caption}</p>
        {many ? (
          <button type="button" className="icon-btn" onClick={next} aria-label="Next image"><Icon name="arrowRight" /></button>
        ) : <span />}
      </div>
    </div>,
    document.body,
  );
}

/** Hook: manage a lightbox for a list of images. */
export function useLightbox(items: LightboxItem[]) {
  const [open, setOpen] = useState<number | null>(null);
  const node = open === null ? null : (
    <Lightbox items={items} index={open} onIndex={setOpen} onClose={() => setOpen(null)} />
  );
  return { openAt: setOpen, node };
}

interface ZoomProps {
  onOpen: () => void;
  src: string;
  alt: string;
  className?: string;
  loading?: 'lazy' | 'eager';
  width?: number;
  height?: number;
  children?: ReactNode;
}

/** An image button that opens the lightbox. */
export function ZoomImage({ onOpen, src, alt, className, loading = 'lazy', width, height }: ZoomProps) {
  return (
    <button type="button" className={`zoomable ${className ?? ''}`} onClick={onOpen} aria-label={`Enlarge image: ${alt}`}>
      <img src={src} alt={alt} loading={loading} decoding="async" width={width} height={height} />
      <span className="zoomable__hint" aria-hidden="true"><Icon name="expand" /></span>
    </button>
  );
}
