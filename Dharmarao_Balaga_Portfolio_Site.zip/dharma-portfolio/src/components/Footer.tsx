import { Link } from '../lib/router';
import { site } from '../data/site';

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="footer">
      <div className="wrap footer__inner">
        <p>© {year} {site.name}. Designed with intent by Dharma Rao.</p>
        <nav aria-label="Footer">
          <Link to="/work">Selected Work</Link>
          <Link to="/cover-letter">Cover Letter</Link>
          <Link to="/resume">Resume</Link>
          <a href={`mailto:${site.email}`}>Email</a>
          <a href={site.linkedin} target="_blank" rel="noopener noreferrer">LinkedIn</a>
          <a href={site.behance} target="_blank" rel="noopener noreferrer">Behance</a>
        </nav>
      </div>
    </footer>
  );
}
