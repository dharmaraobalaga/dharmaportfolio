import { useEffect, useState } from 'react';
import { Link, useRoute } from '../lib/router';
import { site } from '../data/site';

const items = [
  { to: '/profile', label: 'My Profile', match: (r: string) => r === '/profile' },
  { to: '/work', label: 'Selected Work', match: (r: string) => r === '/work' || r.startsWith('/work/') },
  { to: '/cover-letter', label: 'Cover Letter', match: (r: string) => r === '/cover-letter' },
  { to: '/resume', label: 'Resume', match: (r: string) => r === '/resume', cta: true },
];

export function Navbar() {
  const route = useRoute();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => setOpen(false), [route]);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    on();
    window.addEventListener('scroll', on, { passive: true });
    return () => window.removeEventListener('scroll', on);
  }, []);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <header className={`nav${scrolled || open ? ' is-scrolled' : ''}`}>
      <div className="wrap nav__inner">
        <Link to="/" className="wordmark" aria-label={`${site.name}, home`}>
          <span className="wordmark__name">Dharmarao Balaga</span>
        </Link>
        <nav aria-label="Primary">
          <button
            type="button"
            className="nav__toggle"
            aria-expanded={open}
            aria-controls="primary-nav"
            aria-label={open ? 'Close menu' : 'Open menu'}
            onClick={() => setOpen((v) => !v)}
          >
            <span />
          </button>
          <ul id="primary-nav" className={`nav__list${open ? ' is-open' : ''}`}>
            {items.map((it) => (
              <li key={it.to} style={{ display: 'contents' }}>
                <Link
                  to={it.to}
                  className={`nav__link${it.cta ? ' nav__link--cta' : ''}`}
                  aria-current={it.match(route) ? 'page' : undefined}
                >
                  {it.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
}
