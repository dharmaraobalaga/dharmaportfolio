const strengths = [
  'Product Design Strategy',
  'UX Research and Problem Framing',
  'Information Architecture and User Journeys',
  'Interaction Design and Prototyping',
  'Design Systems and Component Libraries',
  'Product Design Leadership and Mentoring',
  'AI-Assisted Research and Design',
  'Human-Centred AI Experiences',
  'Visual Communication and Storytelling',
  'Cross-Functional Collaboration',
];

const tools = ['Figma', 'Figma Make', 'Google Stitch', 'ChatGPT', 'Claude', 'Google Gemini', 'Midjourney', 'Leonardo AI', 'Runway ML'];

const career = [
  { when: 'Feb 2025 – Present', role: 'Founder & Principal Product Designer', org: 'D’SARAS Design Studio, Hyderabad' },
  { when: 'Jan 2018 – Jan 2025', role: 'Head of Product Design', org: 'Openplay Technologies (Nazara Group), Hyderabad' },
  { when: 'Mar 2014 – Jan 2018', role: 'Design Manager / Creative Head', org: 'Adeon Media Technologies, Hyderabad' },
  { when: '2001 – 2014', role: 'Illustrator → Graphic Designer → Animator → Team Lead', org: 'Software, e-learning and animation studios' },
];

export function ProfileSection() {
  return (
    <section id="profile" className="section profile" aria-labelledby="profile-title">
      <div className="wrap profile__grid">
        <div className="profile__sticky">
          <p className="eyebrow eyebrow--accent">My Profile</p>
          <h2 id="profile-title" className="h-2">Experience shaped by design, technology, and storytelling.</h2>
        </div>
        <div>
          <div className="prose reveal">
            <p>
              I’m a product design professional with nearly two decades of experience spanning UX/UI, digital product
              design, animation, visual communication, and creative direction.
            </p>
            <p>
              My career has evolved from visual design and animation into product design strategy and leadership. At
              Openplay Technologies, I led product design for seven years, collaborating with product, engineering,
              marketing, and leadership teams.
            </p>
            <p>
              As Founder and Principal Product Designer at D’SARAS Design Studio, I work across product strategy, UX/UI
              consulting, design systems, and AI-enabled design workflows.
            </p>
            <p>
              My approach combines user-centred thinking, visual craft, systems thinking, and practical experimentation
              with emerging technologies.
            </p>
          </div>

          <h3 className="sr-only">Strengths</h3>
          <ol className="strengths reveal">
            {strengths.map((s, i) => (
              <li key={s}><span>{String(i + 1).padStart(2, '0')}</span>{s}</li>
            ))}
          </ol>

          <div className="tools reveal">
            <h3 className="eyebrow">Tools</h3>
            <ul className="chips">
              {tools.map((t) => <li key={t}>{t}</li>)}
            </ul>
            <p className="muted" style={{ marginTop: 14, fontSize: 'var(--fs-sm)', maxWidth: '60ch' }}>
              AI is a practical extension of design judgement in my work, not a replacement for research or design
              expertise.
            </p>
          </div>

          <div className="reveal">
            <h3 className="eyebrow" style={{ marginTop: 40 }}>Career path</h3>
            <ul className="career">
              {career.map((c) => (
                <li key={c.when}>
                  <span className="when">{c.when}</span>
                  <span><b>{c.role}</b><span className="muted">{c.org}</span></span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
