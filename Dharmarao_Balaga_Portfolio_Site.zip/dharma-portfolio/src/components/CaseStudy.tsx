import { useEffect, useState, type ReactNode } from 'react';
import { Link, scrollToId } from '../lib/router';
import { projects, type ProjectSlug } from '../data/projects';
import { site } from '../data/site';
import { ContactButton } from './ContactButton';
import { Icon } from './Icon';

/* ---------- Hero ---------- */

interface MetaItem { k: string; v: ReactNode }

interface HeroProps {
  slug: ProjectSlug;
  eyebrow: string;
  title: string;
  lede: ReactNode;
  tags: { label: string; kind?: 'status' | 'concept' }[];
  meta: MetaItem[];
  prototype?: { href: string; label: string };
  /** Optional secondary external link, e.g. a Behance project. */
  extraLink?: { href: string; label: string };
  media: ReactNode;
  notice?: ReactNode;
}

export function CaseHero({ eyebrow, title, lede, tags, meta, prototype, extraLink, media, notice }: HeroProps) {
  return (
    <header className="cs-hero">
      <div className="wrap">
        <Link to="/work" className="cs-back"><Icon name="arrowLeft" /> All selected work</Link>
        <div className="cs-hero__top">
          <span className="eyebrow eyebrow--accent" style={{ marginRight: 6 }}>{eyebrow}</span>
          {tags.map((t) => (
            <span key={t.label} className={`tag${t.kind ? ` tag--${t.kind}` : ''}`}>{t.label}</span>
          ))}
        </div>
        <h1 className="cs-hero__title">{title}</h1>
        <p className="cs-hero__lede">{lede}</p>
        <div className="btn-row cs-hero__actions">
          {prototype && (
            <a className="btn btn--primary" href={prototype.href} target="_blank" rel="noopener noreferrer">
              {prototype.label} <Icon name="arrowUpRight" />
              <span className="sr-only">(opens in a new tab)</span>
            </a>
          )}
          {extraLink && (
            <a className="btn btn--ghost" href={extraLink.href} target="_blank" rel="noopener noreferrer">
              {extraLink.label} <Icon name="arrowUpRight" />
              <span className="sr-only">(opens in a new tab)</span>
            </a>
          )}
          <button type="button" className="btn btn--ghost" onClick={() => scrollToId('final')}>See the final screens</button>
        </div>
        <dl className="cs-meta">
          {meta.map((m) => (
            <div key={m.k}><dt>{m.k}</dt><dd>{m.v}</dd></div>
          ))}
        </dl>
        {notice}
        <div className="cs-hero__media">{media}</div>
      </div>
    </header>
  );
}

export function Notice({ children, kind = 'warn' }: { children: ReactNode; kind?: 'warn' | 'info' }) {
  return (
    <div className={`notice${kind === 'info' ? ' notice--info' : ''}`} role="note">
      <Icon name="info" />
      <div>{children}</div>
    </div>
  );
}

/* ---------- Sticky section navigation with scroll-spy ---------- */

export function SubNav({ items }: { items: { id: string; label: string }[] }) {
  const [active, setActive] = useState(items[0]?.id);
  useEffect(() => {
    if (!('IntersectionObserver' in window)) return;
    const io = new IntersectionObserver(
      (entries) => {
        const vis = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (vis[0]) setActive(vis[0].target.id);
      },
      { rootMargin: '-140px 0px -60% 0px' },
    );
    items.forEach((it) => { const el = document.getElementById(it.id); if (el) io.observe(el); });
    return () => io.disconnect();
  }, [items]);
  return (
    <nav className="cs-subnav" aria-label="Case study sections">
      <div className="wrap">
        <ul>
          {items.map((it) => (
            <li key={it.id}>
              <button type="button" aria-current={active === it.id ? 'true' : undefined} onClick={() => scrollToId(it.id)}>
                {it.label}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
}

/* ---------- Section ---------- */

interface SectionProps {
  id: string;
  n: string;
  label: string;
  title: string;
  intro?: ReactNode;
  children?: ReactNode;
  /** Content that spans the full container width below the text column. */
  wide?: ReactNode;
  /** Render children at full container width instead of the text column. */
  full?: boolean;
}

export function Section({ id, n, label, title, intro, children, wide, full }: SectionProps) {
  const hid = `${id}-title`;
  return (
    <section id={id} className="cs-sec" aria-labelledby={hid}>
      <div className="wrap">
        <div className="cs-sec__head">
          <p className="cs-sec__label"><b>{n}</b>{label}</p>
          <div>
            <h2 id={hid} className="cs-sec__title">{title}</h2>
            {intro && <div className="prose cs-sec__intro">{intro}</div>}
          </div>
        </div>
        {children && full && <div className="cs-wide">{children}</div>}
        {children && !full && (
          <div className="cs-body">
            <div />
            <div className="cs-body__main">{children}</div>
          </div>
        )}
        {wide && <div className="cs-wide">{wide}</div>}
      </div>
    </section>
  );
}

/* ---------- Pieces ---------- */

export function HMW({ children }: { children: ReactNode }) {
  return (
    <div className="hmw">
      <span className="eyebrow">How might we</span>
      <p>{children}</p>
    </div>
  );
}

export function Persona({ tag, name, sub, quote, rows }: { tag: string; name: string; sub: string; quote: string; rows: [string, string][] }) {
  return (
    <article className="persona">
      <span className="eyebrow eyebrow--accent">{tag}</span>
      <div>
        <h3 className="persona__name">{name}</h3>
        <p className="persona__sub">{sub}</p>
      </div>
      <blockquote>“{quote}”</blockquote>
      <dl>
        {rows.map(([k, v]) => (
          <div key={k}><dt>{k}</dt><dd>{v}</dd></div>
        ))}
      </dl>
    </article>
  );
}

export function Decision({ n, title, children, tradeoff, media, status, phone }: { n: number; title: string; children: ReactNode; tradeoff: ReactNode; media?: ReactNode; status?: string; phone?: boolean }) {
  return (
    <article className={`decision${media ? '' : ' decision--text'}`}>
      <div>
        <span className="decision__n">Decision {n}</span>
        <h3>{title}</h3>
        {children}
        <p className="tradeoff"><b>Trade-off: </b>{tradeoff}</p>
        {status && <span className="status">{status}</span>}
      </div>
      {media && <div className={`decision__media${phone ? ' decision__media--phone' : ''}`}>{media}</div>}
    </article>
  );
}

export function Prototype({ href, title, body, cta }: { href?: string; title: string; body: string; cta: string }) {
  return (
    <div className="proto">
      <div>
        <strong>{title}</strong>
        <p>{body}</p>
      </div>
      {href ? (
        <a className="btn btn--on-dark" href={href} target="_blank" rel="noopener noreferrer">
          {cta} <Icon name="arrowUpRight" /><span className="sr-only">(opens in a new tab)</span>
        </a>
      ) : (
        <span className="btn btn--ghost-dark" aria-disabled="true">Link coming soon</span>
      )}
    </div>
  );
}

export function Swatches({ colors }: { colors: { hex: string; name?: string; note?: string }[] }) {
  return (
    <ul className="swatches">
      {colors.map((c) => (
        <li key={c.hex}>
          <i style={{ background: c.hex }} />
          {c.name && <b>{c.name}</b>}
          {c.hex}{c.note ? ` · ${c.note}` : ''}
        </li>
      ))}
    </ul>
  );
}

/* ---------- Footer of case study: pager + CTA ---------- */

export function CaseFooter({ slug }: { slug: ProjectSlug }) {
  const i = projects.findIndex((p) => p.slug === slug);
  const prev = projects[(i - 1 + projects.length) % projects.length];
  const next = projects[(i + 1) % projects.length];
  return (
    <div className="wrap" style={{ paddingBottom: 'var(--section)' }}>
      <nav className="pager" aria-label="More case studies">
        <Link to={prev.route}>
          <span className="k"><Icon name="arrowLeft" /> Previous project</span>
          <b>{prev.title}</b>
          <span className="d">{prev.tagline}</span>
        </Link>
        <Link to={next.route}>
          <span className="k">Next project <Icon name="arrowRight" /></span>
          <b>{next.title}</b>
          <span className="d">{next.tagline}</span>
        </Link>
      </nav>
      <div className="cta-band">
        <div>
          <h2 className="h-3">Let’s build something meaningful.</h2>
          <p>Open to conversations about product design leadership, principal designer roles, AI-driven product experiences and selected consulting work.</p>
        </div>
        <div className="btn-row">
          <ContactButton label="Contact me" className="btn btn--on-dark" />
          <a className="btn btn--ghost-dark" href={site.documents.resume.href} download={site.documents.resume.filename}><Icon name="download" /> Resume</a>
        </div>
      </div>
    </div>
  );
}
