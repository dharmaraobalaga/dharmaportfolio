import { Link } from '../lib/router';
import type { ProjectSummary } from '../data/projects';
import { Icon } from './Icon';

function Cover({ p }: { p: ProjectSummary }) {
  if (p.slug === 'twam') {
    return (
      <div className="comp comp--twam">
        {p.cover.map((src, i) => (
          <img key={src} src={src} alt={p.coverAlt[i]} loading="lazy" width={403} height={959} />
        ))}
      </div>
    );
  }
  if (p.slug === 'resolveai') {
    return (
      <div className="comp comp--resolve">
        <img src={p.cover[0]} alt={p.coverAlt[0]} loading="lazy" width={1776} height={1234} />
      </div>
    );
  }
  return (
    <div className="comp comp--rummy">
      <img src={p.cover[0]} alt={p.coverAlt[0]} loading="lazy" width={1084} height={1010} />
    </div>
  );
}

export function ProjectCard({ p }: { p: ProjectSummary }) {
  const titleId = `project-${p.slug}`;
  return (
    <article className="pcard reveal" aria-labelledby={titleId}>
      <Link to={p.route} className="pcard__media" tabIndex={-1} aria-hidden="true">
        <Cover p={p} />
      </Link>
      <div className="pcard__body">
        <span className="pcard__num">{p.number} / 03</span>
        <p className="eyebrow">{p.category}</p>
        <h3 id={titleId} className="pcard__title">
          <Link to={p.route}>{p.title}</Link>
        </h3>
        <p className="pcard__tagline">{p.tagline}</p>
        <p className="pcard__desc">{p.description}</p>
        <dl className="pcard__meta">
          <dt>Context</dt><dd>{p.context}</dd>
          <dt>My role</dt><dd>{p.role}</dd>
          <dt>Status</dt><dd>{p.status}</dd>
        </dl>
        <Link to={p.route} className="text-link" aria-label={`Read case study: ${p.title}`}>
          Read case study <Icon name="arrowRight" />
        </Link>
      </div>
    </article>
  );
}
