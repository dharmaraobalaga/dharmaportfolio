import { useEffect, useId, useRef, useState } from 'react';
import { site } from '../data/site';
import { Icon } from './Icon';

interface Props {
  label?: string;
  className?: string;
  /** Which side the panel opens towards. */
  align?: 'left' | 'right';
}

/**
 * "Contact me" button that reveals the email address with Copy and Open-email actions.
 * Works even where mailto: links are blocked, because the address is always visible and copyable.
 */
export function ContactButton({ label = 'Contact Me', className = 'btn btn--ghost', align = 'left' }: Props) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);
  const id = useId();

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => { if (wrap.current && !wrap.current.contains(e.target as Node)) setOpen(false); };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    window.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDoc); window.removeEventListener('keydown', onKey); };
  }, [open]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(site.email);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      const el = document.getElementById(`${id}-email`);
      if (el) { const r = document.createRange(); r.selectNodeContents(el); const s = window.getSelection(); s?.removeAllRanges(); s?.addRange(r); }
    }
  };

  return (
    <div className={`contact-pop contact-pop--${align}`} ref={wrap}>
      <button type="button" className={className} aria-expanded={open} aria-controls={`${id}-panel`} onClick={() => setOpen((v) => !v)}>
        <Icon name="mail" /> {label}
      </button>
      {open && (
        <div className="contact-pop__panel" id={`${id}-panel`} role="dialog" aria-label="Email address">
          <span className="contact-pop__k">Email</span>
          <span className="contact-pop__email" id={`${id}-email`}>{site.email}</span>
          <div className="contact-pop__actions">
            <button type="button" className="btn btn--dark" onClick={copy}>
              <Icon name="copy" /> {copied ? 'Copied' : 'Copy email'}
            </button>
            <a className="btn btn--ghost" href={`mailto:${site.email}?subject=${encodeURIComponent('Product design opportunity')}`}>
              <Icon name="mail" /> Open email app
            </a>
          </div>
          <span className="contact-pop__phone">Phone: <a href={site.phoneHref}>{site.phone}</a></span>
          <span className="sr-only" aria-live="polite">{copied ? 'Email address copied' : ''}</span>
        </div>
      )}
    </div>
  );
}
