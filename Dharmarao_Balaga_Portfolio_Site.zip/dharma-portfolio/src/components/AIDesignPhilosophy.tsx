import { Link } from '../lib/router';

const principles = [
  {
    title: 'Explore faster',
    body: 'Use AI for early ideation, research synthesis, and rapid prototyping, so more options get compared before any one gets polished.',
  },
  {
    title: 'Design responsibly',
    body: 'Make AI outputs understandable, reviewable, and appropriate to the context: label what is generated, show where it came from, say what isn’t known.',
  },
  {
    title: 'Keep people in control',
    body: 'Build experiences where users can inspect, correct, override, or reject AI suggestions, and where nothing consequential happens without a person’s approval.',
  },
];

export function AIDesignPhilosophy() {
  return (
    <section className="section ai" aria-labelledby="ai-title">
      <div className="wrap">
        <div className="ai__head reveal">
          <p className="eyebrow">How I work with AI</p>
          <h2 id="ai-title" className="h-2">AI should accelerate design, not replace design judgement.</h2>
          <p>
            I use AI to explore possibilities faster, synthesise information, generate and compare concepts, and shorten
            the path from an idea to a working prototype. The responsibility for defining the problem, evaluating
            trade-offs, ensuring usability, and making the final design decisions remains human.
          </p>
        </div>
        <ol className="principles reveal">
          {principles.map((p, i) => (
            <li key={p.title}>
              <span className="n">0{i + 1}</span>
              <h3>{p.title}</h3>
              <p>{p.body}</p>
            </li>
          ))}
        </ol>
        <div className="ai__links reveal">
          <span>In practice:</span>
          <Link to="/work/resolveai">ResolveAI: keeping support agents in control of an AI copilot</Link>
          <Link to="/work/twam">TWAM: 135 AI-assisted versions; the tools generated, I decided what stayed</Link>
        </div>
      </div>
    </section>
  );
}
