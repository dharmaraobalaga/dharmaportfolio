import { useEffect, useLayoutEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { ClassicRummy } from './pages/ClassicRummy';
import { ResolveAI } from './pages/ResolveAI';
import { TWAM } from './pages/TWAM';
import { CoverLetter } from './pages/CoverLetter';
import { Resume } from './pages/Resume';
import { NotFound } from './pages/NotFound';
import { scrollToId, useRoute } from './lib/router';

/** Routes that render the homepage and scroll to one of its sections. */
const homeSections: Record<string, string | null> = { '/': null, '/profile': 'profile', '/work': 'work', '/contact': 'contact' };

function pageFor(route: string) {
  if (route in homeSections) return { key: 'home', el: <Home /> };
  switch (route) {
    case '/work/classic-rummy': return { key: route, el: <ClassicRummy /> };
    case '/work/resolveai': return { key: route, el: <ResolveAI /> };
    case '/work/twam': return { key: route, el: <TWAM /> };
    case '/cover-letter': return { key: route, el: <CoverLetter /> };
    case '/resume': return { key: route, el: <Resume /> };
    default: return { key: '404', el: <NotFound /> };
  }
}

export default function App() {
  const route = useRoute();
  const page = pageFor(route);

  useLayoutEffect(() => {
    const section = homeSections[route];
    if (!section) window.scrollTo({ top: 0, behavior: 'instant' });
  }, [route]);

  useEffect(() => {
    const section = homeSections[route];
    if (section) {
      const t = window.setTimeout(() => scrollToId(section), 30);
      return () => window.clearTimeout(t);
    }
    // Move focus to main content on page change for screen-reader and keyboard users.
    document.getElementById('main')?.focus({ preventScroll: true });
  }, [route]);

  return (
    <>
      <a className="skip-link" href="#main" onClick={(e) => { e.preventDefault(); document.getElementById('main')?.focus(); }}>Skip to content</a>
      <Navbar />
      <main id="main" tabIndex={-1} style={{ outline: 'none' }}>
        <div className="page" key={page.key}>{page.el}</div>
      </main>
      <Footer />
    </>
  );
}
