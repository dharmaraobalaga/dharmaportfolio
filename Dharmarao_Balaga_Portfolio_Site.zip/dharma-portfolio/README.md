# Dharmarao Balaga — Product Design Portfolio

React 18 + TypeScript + Vite. Plain CSS with design tokens. No UI framework, no router library, no external requests (the Inter font is self-hosted via `@fontsource-variable/inter`).

## Run

```bash
npm install
npm run dev       # local dev server
npm run build     # production build in dist/
npm run preview   # serve the production build
```

`dist/` is a static site. Upload it to any static host (Netlify, Vercel, GitHub Pages, S3, cPanel). The build uses relative paths (`base: './'`) and hash routing, so it works from a subfolder and needs no server rewrites.

## Pages (hash routes)

| Route | Page |
| --- | --- |
| `#/` | Home: hero, selected work, profile, AI philosophy, contact |
| `#/profile`, `#/work`, `#/contact` | Home, scrolled to that section (nav targets) |
| `#/work/classic-rummy` | Case study 01 |
| `#/work/resolveai` | Case study 02 |
| `#/work/twam` | Case study 03 |
| `#/cover-letter` | Cover letter (download PDF, print, copy text) |
| `#/resume` | Resume (download PDF, open, print) |

## Structure

```
public/
  documents/   Dharmarao_Balaga_Principal_Product_Designer_Resume.pdf  (the supplied resume, unchanged)
               Dharmarao_Balaga_Cover_Letter.pdf                        (generated from the approved letter text)
  images/      dharma-portrait.jpg, rummy/, resolveai/, twam/           (optimised from the supplied case-study exports)
src/
  components/  Navbar, Footer, Hero, ProjectCard, ProjectGallery, Lightbox, ProfileSection,
               AIDesignPhilosophy, ContactSection, CaseStudy (shared case-study template), Icon
  pages/       Home, ClassicRummy, ResolveAI, TWAM, CoverLetter, Resume, NotFound
  data/        site.ts (contact details + document paths), projects.ts (card content)
  lib/         router (hash), asset path helper, title + reveal hooks
  styles/      tokens.css (design tokens), global.css
```

To change contact details or document files, edit `src/data/site.ts` only.

## Content integrity notes

Everything on the site comes from the supplied case studies, resume and brief. Items in the source marked "[confirm]" or left as placeholders were left out rather than guessed:

- **Classic Rummy**: post-launch figures (+40% DAU, +25% returning users) were left out because their source is marked "[confirm]" in the case study. Survey sample size, team headcount and the "screens shown with permission" line were also left out.
- **TWAM**: engagement type (client project vs. studio concept), end date and team composition are marked "[confirm]" in the source, so the site shows "OnlyTWAM · D'SARAS Design Studio" and "Prototype stage". The resume PDF mentions a "12-screen interactive prototype"; the case study says "20+ screens". The site uses the case study wording.
- **ResolveAI**: clearly labelled as a self-initiated concept with fictional data. Process dates and the list of help-desk tools reviewed were left out (placeholders in source).
- The phone number appears only in the downloadable resume PDF, not on the website.

## External links used

- Classic Rummy Figma prototype: https://www.figma.com/proto/7ATYEy8vBkBD2cpt0nprZR/Classic-Rummy-Prototype
- ResolveAI interactive prototype: https://claude.ai/artifact/8A5vvbdMmB5Pnpqrit4yB9
- TWAM Figma Make prototype: https://www.figma.com/make/TqlzaTuAIfLUywlKZFHwvD/Mobile-App-for-Twam

Check that each prototype is set to public / "anyone with the link" before sharing the site.
